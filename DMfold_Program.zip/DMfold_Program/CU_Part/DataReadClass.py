import h5py as h5
class DataRead:
    def PriArchiveData(self): # Read the real data to calculate the accuracy of the prediction results
        PriTestFile = h5.File('Real_Data/TestData-7.h5', 'r')
        PriTestSeqList = PriTestFile['SeqList'][:]
        PriTestStructureList = PriTestFile['StructureList'][:]
        PriTestLengthList = PriTestFile['Length'][:]
        PriTestList = PriTestFile['PriList'][:]
        PriFileTestIndex = PriTestFile['FileIndex'][:]
        # Return the reading data.
        return PriTestSeqList, PriTestStructureList, PriTestLengthList, PriTestList, PriFileTestIndex  # 数据类型均为<class 'numpy.ndarray'>
    def PreStructureData(self): # Read the prediction results
        PreSecStructureTest = h5.File('Saver_Result/First/Test_RnasepPre.h5', 'r')
        PreStructureTest = PreSecStructureTest['PreStructure'][:]
        PreSecStructureTest.close()
        return PreStructureTest