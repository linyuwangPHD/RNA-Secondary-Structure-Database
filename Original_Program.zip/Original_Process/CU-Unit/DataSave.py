import tensorflow as tf  # 导入Tensorflow模块包
import numpy as np # 导入numpy模块包
import SecondaryDataRead as sd
import h5py as h5
HIDDEN_SIZE = 300 # LSTM隐藏层节点个数
NUM_LAYERS = 3  # LSTM网络的层数
NUM_INPUT = 8   # 每一步输入节点的个数
N_CLASSES = 7   # 每一步的分类
TRAIN_BATCH_SIZE = 16    # 训练数据batch大小
TEST_BATCH_SIZE = 71  # 测试数据batch大小
TESTTRAIN_BATCH_SIZE = 2515
TRAIN_NUM_STEP = 300    # 训练网络时间步数
LSTM_KEEP_PROB = 0.8  # 节点非Dropout的比率
FULL_LAYER_DROPOUT = 0.8
class PaperModel(object): # 创建模型类
    def __init__(self, is_training ,batch_size, num_steps, n_input, n_classes):# is_training是否时训练集，batch_size：batch大小，num_steps：网络时间步数，n_input：每一步输入节点个数，n_classes：每一步分类
        self.batch_size = batch_size # 模型的batch_size赋值为传入值batch_size
        self.num_steps = num_steps  # 模型的num_steps赋值为传入的num_steps
        self.n_input = n_input      # 模型的n_input赋值为传入的n_input
        self.n_classes = n_classes  # 模型的n_classes赋值为传入的n_input
        self.input_data = tf.placeholder(tf.float32, [None, num_steps, n_input]) # 定义输入数据格式为[None, num_steps, n_input]
        self.targets = tf.placeholder(tf.float32, [None, num_steps, n_classes]) # 定义输出数据格式[None, num_steps, n_classes]
        dropout_keep_prob = LSTM_KEEP_PROB if is_training else 1.0 # 如果时训练集dropout_keep_prob=0.9， 如果时测试集合dropout_keep_prob=1.0
        # 定义前向传播的lstm单元
        lstm_fw_cell = [tf.nn.rnn_cell.DropoutWrapper(tf.nn.rnn_cell.BasicLSTMCell(HIDDEN_SIZE), output_keep_prob=dropout_keep_prob) for _ in range(NUM_LAYERS)]
        # 定义反向传播的lstm单元
        lstm_bw_cell = [tf.nn.rnn_cell.DropoutWrapper(tf.nn.rnn_cell.BasicLSTMCell(HIDDEN_SIZE), output_keep_prob=dropout_keep_prob) for _ in range(NUM_LAYERS)]
        # 定义多层式的前向传播单元
        fw_cell = tf.nn.rnn_cell.MultiRNNCell(lstm_fw_cell)
        #定义多层式的额反向传播单元
        bw_cell = tf.nn.rnn_cell.MultiRNNCell(lstm_bw_cell)
        self.input_dataone = tf.transpose(self.input_data, [1, 0, 2])
        self.input_dataone = tf.reshape(self.input_dataone, [-1, NUM_INPUT])
        self.input_dataone = tf.split(self.input_dataone, TRAIN_NUM_STEP) # 把输入数据转化为适合LSTM处理的数据,把数据制作成batch类型
        outputs, _, _ = tf.nn.static_bidirectional_rnn(fw_cell, bw_cell, self.input_dataone, dtype=tf.float32)  # outputs为Lstm输出, outputs的形状为[num_steps, batch_size, 2*HIDDEN]
        outputs = tf.reshape(tf.concat(outputs, 1), [-1, 2*HIDDEN_SIZE]) # 先把outputs变换为[batch, 2*HIDDEN*num_steps]，然后转换为[batch*num_steps, 2*HIDDEN]格式
        weightone = tf.get_variable("weightone", [2*HIDDEN_SIZE, HIDDEN_SIZE]) # 定义softmax的权重，
        biasone = tf.get_variable('biasone', [HIDDEN_SIZE]) # 定义softmax的偏向
        weighttwo = tf.get_variable("weighttwo", [HIDDEN_SIZE, HIDDEN_SIZE/2]) # 定义softmax的权重，
        biastwo = tf.get_variable('biastwo', [HIDDEN_SIZE/2]) # 定义softmax的偏向
        weightthree = tf.get_variable("weight", [HIDDEN_SIZE/2, N_CLASSES]) # 定义softmax的权重，
        biasthree = tf.get_variable('bias', [N_CLASSES]) # 定义softmax的偏向
        full_dropout_keep_prob = FULL_LAYER_DROPOUT if is_training else 1.0
        layer1 = tf.nn.relu(tf.matmul(outputs, weightone) + biasone)  # 计算softmax的值，logits的维度为[batch*num_steps, n_classes]
        layer1 = tf.nn.dropout(layer1, full_dropout_keep_prob)
        layer2 = tf.nn.relu(tf.matmul(layer1, weighttwo) + biastwo)
        layer2 = tf.nn.dropout(layer2, full_dropout_keep_prob)
        self.logits = tf.nn.softmax(tf.matmul(layer2, weightthree) + biasthree)  # 计算softmax的值，logits的维度为[batch*num
def Test(session, test_x, test_y,model):
    print(len(test_x))
    logits = session.run([model.logits],feed_dict={model.input_data: test_x, model.targets: test_y})
    return logits
def TestTrain(session, test_x, test_y,model):
    print(len(test_x))
    logits = session.run([model.logits],feed_dict={model.input_data: test_x, model.targets: test_y})
    return logits
if __name__ == "__main__":
    initializer = tf.random_uniform_initializer(-0.05, 0.05)
    with tf.variable_scope("Paper_Model", reuse=None, initializer=initializer):
        test_model = PaperModel(False, TEST_BATCH_SIZE, TRAIN_NUM_STEP, NUM_INPUT, N_CLASSES)
    with tf.variable_scope("Paper_Model", reuse=True, initializer=initializer):
        testTrain_model = PaperModel(False, TESTTRAIN_BATCH_SIZE, TRAIN_NUM_STEP, NUM_INPUT, N_CLASSES)
    train_x, train_y, train_l, test_x, test_y, test_l = sd.MatureReadTrainDataBatch()
    AccuracyTrain, AccurayTest = sd.Accuracy(train_l, test_l)
    AccuracyTrain = np.reshape(AccuracyTrain, [-1, 7])
    AccurayTest = np.reshape(AccurayTest, [-1, 7])
    saver = tf.train.Saver(max_to_keep=200)
    with tf.Session() as sess:
        saver.restore(sess, 'Validation/Tenth/Model/model.ckpt-186')
        Testlogits = Test(sess, test_x, test_y, test_model)
        Trainlogits = TestTrain(sess, train_x, train_y,  testTrain_model)
        Testlogits = np.reshape(Testlogits, [-1, 7])

        Trainlogits = np.reshape(Trainlogits, [-1, 7])
        #for i in range(300):
        #    print(Testlogits[i])
        Testlogits = Testlogits*AccurayTest
        Trainlogits = Trainlogits*AccuracyTrain
        for i in range(100):
            print("%%%%%%%%%%%%%%%%%%%%%%")
            print(Testlogits[i])
            print(test_y[0][i])
        test_y = np.reshape(test_y, [-1, 7])
        Test =tf.argmax(Testlogits, 1)
        Train = tf.argmax(Trainlogits, 1)
        test_y = tf.argmax(test_y, 1)
        Count = 0
        CC = 0


        Test = sess.run(Test)
        Train = sess.run(Train)
        test_y = sess.run(test_y)
        for iii in range(len(test_y)):
            if (test_y[iii] == Test[iii]):
                Count += 1
            CC += 1
        print("%%%$$$$$$$$$$$$$####################")
        print(len(np.array(test_y)))
        print(len(np.array(Test)))
        Count = 0
        CC = 0

        for iii in range(len(np.array(test_y))):
            if (test_y[iii] == Test[iii]):
                Count += 1
            CC += 1
        print("%%%$$$$$$$$$$$$$####################")
        print(len(np.array(test_y)))
        print(len(np.array(Test)))
        print(Count)
        print(CC)
        print(Count/CC)
        print(type(Test))
        print(type(Train))
        TestlogitsNew  = []
        TrainlogitsNew = []
        for i in range(len(Test)):
            if (Test[i] == 0):
                TestlogitsNew.append([1, 0, 0, 0, 0, 0, 0])
            elif (Test[i] == 1):
                TestlogitsNew.append([0, 1, 0, 0, 0, 0, 0])
            elif (Test[i] == 2):
                TestlogitsNew.append([0, 0, 1, 0, 0, 0, 0])
            elif (Test[i] == 3):
                TestlogitsNew.append([0, 0, 0, 1, 0, 0, 0])
            elif (Test[i] == 4):
                TestlogitsNew.append([0, 0, 0, 0, 1, 0, 0])
            elif (Test[i] == 5):
                TestlogitsNew.append([0, 0, 0, 0, 0, 1, 0])
            else:
                TestlogitsNew.append([0, 0, 0, 0, 0, 0, 1])
        for i in range(len(Train)):
            if (Train[i] == 0):
                TrainlogitsNew.append([1, 0, 0, 0, 0, 0, 0])
            elif (Train[i] == 1):
                TrainlogitsNew.append([0, 1, 0, 0, 0, 0, 0])
            elif (Train[i] == 2):
                TrainlogitsNew.append([0, 0, 1, 0, 0, 0, 0])
            elif (Train[i] == 3):
                TrainlogitsNew.append([0, 0, 0, 1, 0, 0, 0])
            elif (Train[i] == 4):
                TrainlogitsNew.append([0, 0, 0, 0, 1, 0, 0])
            elif (Train[i] == 5):
                TrainlogitsNew.append([0, 0, 0, 0, 0, 1, 0])
            else:
                TrainlogitsNew.append([0, 0, 0, 0, 0, 0, 1])
        TestlogitsNew = np.array(TestlogitsNew)
        TrainlogitsNew = np.array(TrainlogitsNew)
        TestlogitsNew = TestlogitsNew*AccurayTest
        TrainlogitsNew = TrainlogitsNew*AccuracyTrain
        TestlogitsNew = np.reshape(TestlogitsNew, [-1, 300, 7])
        TrainlogitsNew = np.reshape(TrainlogitsNew, [-1, 300, 7])
        print(TestlogitsNew.shape)
        print(TrainlogitsNew.shape)
        TrainPreStr = h5.File('Validation/Third/Model/Secondary5stStrTrainPre.h5', 'w')
        TestPreStr = h5.File('Validation/Tenth/OLD5sRNA-7.h5', 'w')
        TrainPreStr.create_dataset('PreStructure', data=TrainlogitsNew)
        TestPreStr.create_dataset('PreStructure', data=TestlogitsNew)
