import h5py as h5
import numpy as np
def MatureReadTrainDataBatch():
    Train = h5.File('Validation/Secondary/ValidationSecondaryTrainData-7.h5', 'r')   #OneHot-train.h5
    train_x = Train['SeqList'][:]
    train_y = Train['StructureList'][:]
    train_l = Train['Length'][:]
    Train.close()
    Test = h5.File('Validation/TestData-7.h5', 'r')
    test_x = Test['SeqList'][:]
    test_y = Test['StructureList'][:]
    test_l = Test['Length'][:]
    print(np.array(train_x).shape)
    print(np.array(train_y).shape)
    print(np.array(test_y).shape)
    print(np.array(train_x).shape)
    print()
    Test.close()
    print(train_l[0:10])
    print(test_l[0:10])
    return np.array(train_x),np.array(train_y), np.array(train_l), np.array(test_x), np.array(test_y), np.array(test_l)
def Accuracy(train_l, test_l):
    AccuracyTrain = [] # 训练数据长度列表
    AccurayTest = [] # 测试数据长度列表
    ValidationTest = []
    for i in range(len(train_l)): # 遍历所有的循环序列长度
        Accury_train = [] # 创建存储每一个文件的长度列表
        for j in range(300): # 当长度不足300时， 扩充为300
            if(j<train_l[i]): # 当长度没有遍历完时，添加[1, 1, 1, 1, 1, 1, 1]
                Accury_train.append([1, 1, 1, 1, 1, 1, 1])
            else: # 长度遍历完了添加[0, 0, 0, 0, 0, 0, 0]
                Accury_train.append([0, 0, 0, 0, 0, 0, 0])
        AccuracyTrain.append(Accury_train)
    for i in range(len(test_l)):
        Accur_test = []
        for j in range(300):
            if(j<test_l[i]):
                Accur_test.append([1, 1, 1, 1, 1, 1, 1])
            else:
                Accur_test.append([0, 0, 0, 0, 0, 0, 0])
        AccurayTest.append(Accur_test)
    return np.array(AccuracyTrain), np.array(AccurayTest)
def Alllength(train_length):
    Tcount = 0
    for i in range(len(train_length)):
        Tcount += train_length[i]
    return Tcount/len(train_length) # 返回每个batch运算中数据的真实平均长度
MatureReadTrainDataBatch()
