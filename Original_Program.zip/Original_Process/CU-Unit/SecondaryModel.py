import tensorflow as tf  # 导入Tensorflow模块包
import numpy as np # 导入numpy模块包
import SecondaryDataRead as sd
HIDDEN_SIZE = 300 # LSTM隐藏层节点个数
NUM_LAYERS = 3  # LSTM网络的层数
NUM_INPUT = 8   # 每一步输入节点的个数
N_CLASSES = 7   # 每一步的分类
TRAIN_BATCH_SIZE = 16    # 训练数据batch大小
TEST_BATCH_SIZE = 316  # 测试数据batch大小
TESTTRAIN_BATCH_SIZE = 2508
TRAIN_NUM_STEP = 300    # 训练网络时间步数
LSTM_KEEP_PROB = 0.9  # 节点非Dropout的比率
FULL_LAYER_DROPOUT = 0.9
MAX_GRAD_NORM = 5       # 防止梯度爆炸的阈值
LEARNing_rate_base = 0.005 # 基本学习率
LEARNING_RATE_DECAY = 0.99
# 自动衰减率
#REGULARIZATION_RATE = 0.001
class PaperModel(object): # 创建模型类
    def __init__(self, is_training ,batch_size, num_steps, n_input, n_classes):# is_training是否时训练集，batch_size：batch大小，num_steps：网络时间步数，n_input：每一步输入节点个数，n_classes：每一步分类
        self.batch_size = batch_size # 模型的batch_size赋值为传入值batch_size
        self.num_steps = num_steps  # 模型的num_steps赋值为传入的num_steps
        self.n_input = n_input      # 模型的n_input赋值为传入的n_input
        self.n_classes = n_classes  # 模型的n_classes赋值为传入的n_input
        self.input_data = tf.placeholder(tf.float32, [None, num_steps, n_input]) # 定义输入数据格式为[None, num_steps, n_input]
        self.targets = tf.placeholder(tf.float32, [None, num_steps, n_classes]) # 定义输出数据格式[None, num_steps, n_classes]
        self.length = tf.placeholder(tf.float32, [None]) # 定义输入数据长度格式为[None]
        self.Accuracy = tf.placeholder(tf.float32, [None, num_steps, n_classes]) # 定义输入精确率数据格式为[None, num_steps, 2]
        self.Alllength = tf.placeholder(tf.float32) # 定义当前训练数据或测试数据batch所含数据的真实平均长度
        AccurDemo = tf.reshape(self.Accuracy, [-1, 7]) # 把精确率数据转化为[-1, 2]格式数据
        dropout_keep_prob = LSTM_KEEP_PROB if is_training else 1.0 # 如果时训练集dropout_keep_prob=0.9， 如果时测试集合dropout_keep_prob=1.0
        # 定义前向传播的lstm单元
        lstm_fw_cell = [tf.nn.rnn_cell.DropoutWrapper(tf.nn.rnn_cell.BasicLSTMCell(HIDDEN_SIZE), output_keep_prob=dropout_keep_prob) for _ in range(NUM_LAYERS)]
        # 定义反向传播的lstm单元
        lstm_bw_cell = [tf.nn.rnn_cell.DropoutWrapper(tf.nn.rnn_cell.BasicLSTMCell(HIDDEN_SIZE), output_keep_prob=dropout_keep_prob) for _ in range(NUM_LAYERS)]
        # 定义多层式的前向传播单元
        fw_cell = tf.nn.rnn_cell.MultiRNNCell(lstm_fw_cell)
        #定义多层式的额反向传播单元
        bw_cell = tf.nn.rnn_cell.MultiRNNCell(lstm_bw_cell)
        # 定义前向传播的初始化状态
        #self.fw_initial_state = fw_cell.zero_state(batch_size, tf.float32)
        # 定义反向传播的初始化状态
        #self.bw_initial_cell = bw_cell.zero_state(batch_size, tf.float32)
        self.input_dataone = tf.transpose(self.input_data, [1, 0, 2])
        self.input_dataone = tf.reshape(self.input_dataone, [-1, NUM_INPUT])
        self.input_dataone = tf.split(self.input_dataone, TRAIN_NUM_STEP) # 把输入数据转化为适合LSTM处理的数据,把数据制作成batch类型
        outputs, _, _ = tf.nn.static_bidirectional_rnn(fw_cell, bw_cell, self.input_dataone, dtype=tf.float32)  # outputs为Lstm输出, outputs的形状为[num_steps, batch_size, 2*HIDDEN]
        outputs = tf.reshape(tf.concat(outputs, 1), [-1, 2*HIDDEN_SIZE]) # 先把outputs变换为[batch, 2*HIDDEN*num_steps]，然后转换为[batch*num_steps, 2*HIDDEN]格式
        weightone = tf.get_variable("weightone", [2*HIDDEN_SIZE, HIDDEN_SIZE]) # 定义softmax的权重，
        biasone = tf.get_variable('biasone', [HIDDEN_SIZE]) # 定义softmax的偏向
        weighttwo = tf.get_variable("weighttwo", [HIDDEN_SIZE, HIDDEN_SIZE/2]) # 定义softmax的权重，
        biastwo = tf.get_variable('biastwo', [HIDDEN_SIZE/2]) # 定义softmax的偏向
        weightthree = tf.get_variable("weight", [HIDDEN_SIZE/2, N_CLASSES]) # 定义softmax的权重，
        biasthree = tf.get_variable('bias', [N_CLASSES]) # 定义softmax的偏向
        full_dropout_keep_prob = FULL_LAYER_DROPOUT if is_training else 1.0
        layer1 = tf.nn.relu(tf.matmul(outputs, weightone) + biasone)  # 计算softmax的值，logits的维度为[batch*num_steps, n_classes]
        layer1 = tf.nn.dropout(layer1, full_dropout_keep_prob)
        layer2 = tf.nn.relu(tf.matmul(layer1, weighttwo) + biastwo)
        layer2 = tf.nn.dropout(layer2, full_dropout_keep_prob)
        logits = tf.nn.relu(tf.matmul(layer2, weightthree) + biasthree)  # 计算softmax的值，logits的维度为[batch*num
        correect_pred = tf.equal(tf.argmax(logits*AccurDemo, 1), tf.argmax(tf.reshape(self.targets, [-1, 7])*AccurDemo, 1)) # 计算准确率logits*AccurDemo防止补0节点对准确率的影响
        self.accuracy = tf.reduce_mean(tf.cast(correect_pred, tf.float32)) # 计算平均精确度
        loss = tf.nn.softmax_cross_entropy_with_logits(labels=tf.reshape(self.targets, [-1, 7]), logits=logits) # 计算损失函数
        label_weights = tf.sequence_mask(self.length, maxlen=300, dtype=tf.float32)  # 防止补0节点的误差影响整体损失
        label_weights = tf.reshape(label_weights, [-1]) # 把label_weights转换成一维序列，便于与loss相乘，避免数据补0位置
        #regularizer = tf.contrib.layers.l2_regularizer(REGULARIZATION_RATE)
        #regularization = regularizer(weightone) + regularizer(weighttwo)+regularizer(weightthree)
        self.cost = tf.reduce_mean(loss*label_weights)*(300/self.Alllength) #+ regularization# 计算平均损失函数
        if not is_training: return # 若时训练数据，则运行下面代码，否则返回当前结果
        trainable_variables = tf.trainable_variables() # 定义初始化变量
        grads, _ = tf.clip_by_global_norm(tf.gradients(self.cost, trainable_variables), MAX_GRAD_NORM) # 定义防止梯度爆炸的变量
        global_step = tf.Variable(0, trainable=False) # 定义全局循环轮数
        learning_rate = tf.train.exponential_decay(LEARNing_rate_base, global_step, 100, LEARNING_RATE_DECAY, staircase=True) # 定义学习率自动衰减
        optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate) # 定义模型优化器
        self.train_op = optimizer.apply_gradients(zip(grads, trainable_variables), global_step=global_step) # 定义优化变量train_op
# 训练数据轮次方法，train_x_batch训练序列数据，train_y_batch训练结构数据，训练长度标签数据，AccuracyTrain训练精确度矩阵数据
def Run_epoch(session, train_x_batch, train_y_batch, train_l,AccuracyTrain,model):
    for i in range(100):
        id = np.random.choice(TESTTRAIN_BATCH_SIZE, size=TRAIN_BATCH_SIZE, replace=False)
        train_batch_x = train_x_batch[id]
        train_batch_y = train_y_batch[id]
        train_batch_l = train_l[id]
        AccuracyTrain_batch = AccuracyTrain[id]
        Tcount =sd.Alllength(train_batch_l) # 获得训练batch数据的真实平均长度
        cost, accuracy,  _ = session.run([model.cost, model.accuracy, model.train_op], feed_dict={model.input_data: train_batch_x, model.targets: train_batch_y, model.length: train_batch_l,model.Accuracy:AccuracyTrain_batch, model.Alllength:Tcount})
        if(i%10 ==0): # 每隔10轮输出一次损失函数和精确率
            print(Tcount)
            print("After %d steps, cost is %.3f" % (i, cost))
            print("After %d steps, accuracy is %.3f" % (i,(Tcount-(300-accuracy*300))/Tcount))

def Test(session, test_x, test_y, test_l, AccuracyTest, model):
    Tcount = sd.Alllength(test_l)
    Testcost, accuracy = session.run([model.cost, model.accuracy], feed_dict={model.input_data: test_x, model.targets: test_y, model.length: test_l,model.Accuracy: AccuracyTest, model.Alllength: Tcount})
    print(Tcount)
    print("After %d test, cost is %.3f" % (1, Testcost))
    print("After %d accuracy, cost is %.3f" % (1, (Tcount - (300 - accuracy * 300)) / Tcount))
    return (Tcount - (300 - accuracy * 300)) / Tcount
'''def Test(session, test_x, test_y, test_l, AccuracyTest, model):
    AveCount  = 0
    Aveaccuracy = 0
    AveCost = 0
    for i in range(10):
        id = np.random.choice(len(test_x), size=TEST_BATCH_SIZE, replace=False)
        test_batch_x = test_x[id]
        test_batch_y = test_y[id]
        test_batch_l = test_l[id]
        Tcount = sd.Alllength(test_batch_l)
        AccuracyTest_batch = AccuracyTest[id]# 以上四行，采用随机的方式每次选择batch个数据
        Testcost, accuracy = session.run([model.cost, model.accuracy],feed_dict={model.input_data: test_batch_x, model.targets: test_batch_y, model.length: test_batch_l, model.Accuracy: AccuracyTest_batch, model.Alllength: Tcount})
        Aveaccuracy += (Tcount-(300-accuracy*300))/Tcount
        AveCount += Tcount
        AveCost += Testcost
    print(AveCount/10)
    print("After %d test, cost is %.3f" % (1, AveCost/10))
    print("After %d accuracy, cost is %.3f" % (1, Aveaccuracy/10))
    return Aveaccuracy/10'''
def TestTrain(session, test_x, test_y, test_l, AccuracyTest, model):
    '''id = np.random.choice(len(test_x), size=10000, replace=False)
    test_x = test_x[id]
    test_y = test_y[id]
    test_l = test_l[id]
    AccuracyTest = AccuracyTest[id]'''
    Tcount = sd.Alllength(test_l)
    Testcost, accuracy = session.run([model.cost, model.accuracy], feed_dict={model.input_data: test_x, model.targets: test_y,model.length: test_l, model.Accuracy: AccuracyTest,model.Alllength: Tcount})
    print(Tcount)
    print(len(test_x))
    print("After %d test, cost is %.3f" % (1, Testcost))
    print("After %d accuracy, Traintest accuracy is %.3f" % (1, (Tcount - (300 - accuracy * 300)) / Tcount))
    '''AveCount = 0
    Aveaccuracy = 0
    AveCost = 0
    for i in range(10):
        id = np.random.choice(len(test_x), size=TEST_BATCH_SIZE, replace=False)
        test_batch_x = test_x[id]
        test_batch_y = test_y[id]
        test_batch_l = test_l[id]
        Tcount = sd.Alllength(test_batch_l)
        AccuracyTest_batch = AccuracyTest[id]  # 以上四行，采用随机的方式每次选择batch个数据
        Testcost, accuracy = session.run([model.cost, model.accuracy],feed_dict={model.input_data: test_batch_x, model.targets: test_batch_y,model.length: test_batch_l, model.Accuracy: AccuracyTest_batch,model.Alllength: Tcount})
        Aveaccuracy += (Tcount - (135 - accuracy * 135)) / Tcount
        AveCount += Tcount
        AveCost += Testcost
    print(AveCount / 10)
    print("After %d test, cost is %.3f" % (1, AveCost / 10))
    print("After %d accuracy, cost is %.3f" % (1, Aveaccuracy / 10))'''

if __name__ == "__main__":
    initializer = tf.random_uniform_initializer(-0.05, 0.05)
    with tf.variable_scope("Paper_Model", reuse=None, initializer=initializer):
        train_model = PaperModel(True,TRAIN_BATCH_SIZE, TRAIN_NUM_STEP, NUM_INPUT, N_CLASSES)
    with tf.variable_scope("Paper_Model", reuse=True, initializer=initializer):
        test_model = PaperModel(False, TEST_BATCH_SIZE, TRAIN_NUM_STEP, NUM_INPUT, N_CLASSES)
    with tf.variable_scope("Paper_Model", reuse=True, initializer=initializer):
        testTrain_model = PaperModel(False, TESTTRAIN_BATCH_SIZE, TRAIN_NUM_STEP, NUM_INPUT, N_CLASSES)
    train_x, train_y, train_l, test_x, test_y, test_l = sd.MatureReadTrainDataBatch()
    AccuracyTrain, AccurayTest = sd.Accuracy(train_l, test_l)
    saver = tf.train.Saver(max_to_keep=200)
    with tf.Session() as sess:
        init = tf.global_variables_initializer()
        sess.run(init)
        #saver.restore(sess, 'FourthFamily-7/Secondary/Model/model.ckpt-183')
        count = 0
        index = 0
        for i in range(200):
            print("******************%d********************"%i)
            Run_epoch(sess, train_x, train_y, train_l, AccuracyTrain ,train_model)
            TestAccuracy = Test(sess, test_x, test_y, test_l, AccurayTest,test_model)
            TestTrain(sess, train_x, train_y, train_l, AccuracyTrain, testTrain_model)
            print("######")
            print(TestAccuracy)
            print(count)
            print(index)
            print("######")
            Flag = False
            if(TestAccuracy > count):
                Flag = True
                count = TestAccuracy
                index = i
            if(TestAccuracy>=0.85 and Flag == True):
                saver.save(sess, 'Validation/Secondary/Model1/model.ckpt', global_step=i)

