import DataMerge as dm
import numpy as np
import shutil as st
def DataCreate():
    filehandleRead = open('AllRNA20.fasta', mode='r')
    file_handle = open('MatureAllRNACluster.fasta', mode='w')
    lineOne = filehandleRead.readline()
    Count = 0
    while(lineOne):
        Count += 1
        StrName = lineOne.split()[0] + str(Count) + '-' + lineOne.split()[1]
        file_handle.write(StrName + '\n')
        lineOne = filehandleRead.readline()
        for i in range(len(lineOne)):
            if(lineOne[i] != 'U'):
                file_handle.write(lineOne[i])
            else:
                file_handle.write('T')
        #file_handle.write('\n')
        lineOne = filehandleRead.readline()
        lineOne = filehandleRead.readline()
DataCreate()