import DataMerge as dm
import numpy as np
import shutil as st
filePathCT = 'ThirdMature5stTrain20'
filePathCTOne = 'CT'
def DataCreate():
    num = 0
    nameListCT = dm.EachFile(filePathCT)  # 获得所给路径下所有文件的名字列表
    for i in range(len(np.array(nameListCT))):
        count = 0
        file_handle = open('Mature5stData20Clur.fasta', mode='r')
        line = file_handle.readline()
        while(line):
            flag = False
            if(line[0] == '>'):
                count += 1
            else:
                fore = 0
                erar = 2
                while(fore < len(line)):
                    if(line[fore] == '-'):
                        fore += 1
                        break
                    fore += 1
                while(erar < len(line)):
                    if (line[erar] == 't' and line[erar-1] == 'c' and  line[erar-2] == '.'):
                        erar += 1
                        break
                    erar += 1
                strName = line[fore: erar]
                if(strName == nameListCT[i]):
                    print('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
                    print(strName)
                    print(nameListCT[i])
                    print(count)
                    flag = True
                    break
            if(flag):
                break
            #print("%%%%%%%%%%%%%%%%%%%%%")
           # num += 1
            #print(num)
            line = file_handle.readline()
        #print("$$$$$$$$$$$$$$$$$$$$$$$$$")
        #print(count)
        #print(nameListCT[i])
        file_handleOne = open('Mature5stData20Clur.fasta', mode='r')
        lineOne = file_handleOne.readline()
        countOne = 0
        while(lineOne):
            if(lineOne[0] == '>'):
                countOne += 1
                lineOne = file_handleOne.readline()
                continue
            #print("&&&")
            if(countOne == count):
                fore = 0
                erar = 2
                while (fore < len(lineOne)):
                    if (lineOne[fore] == '-'):
                        fore += 1
                        break
                    fore += 1
                while (erar < len(lineOne)):
                    if (lineOne[erar] == 't' and lineOne[erar - 1] == 'c' and lineOne[erar - 2] == '.'):
                        erar += 1
                        break
                    erar += 1
                Per = len(lineOne)-1
                Pfore = -1
                Perar = -1
                SimPer = 0
                while(Per >= 0):
                    if(lineOne[Per] == '*'):
                        SimPer = 100.0
                        break
                    if(lineOne[Per] != '/'):
                        Per -= 1
                        continue
                    if(lineOne[Per] == '%'):
                        Perar = Per
                        Per -= 1
                        continue
                    if (lineOne[Per] == '/'):
                        Pfore =  Per + 1
                        SimPer = float(lineOne[Pfore: Perar - 1])
                        break
                strNameOne = lineOne[fore: erar]
                #print(strNameOne)
                #print(strNameOne[0])
                #print(strNameOne[-1])
                nameListCTOne = dm.EachFile(filePathCTOne)
                for j in range(len(np.array(nameListCTOne))):
                    if(strNameOne == nameListCTOne[j]):
                        print("@@@@@@@@TTTTTTTTTTTTTTTTTTTT")
                        print(SimPer)
                        print(type(SimPer))
                        num += 1
                        seqPath = dm.FileNmae(filePathCTOne, nameListCTOne[j])
                        st.move(seqPath, 'ThirdMatureAll5stTrainData20-all')
                        break
            #print("****")'''
            lineOne = file_handleOne.readline()

DataCreate()