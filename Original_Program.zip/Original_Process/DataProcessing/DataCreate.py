import DataMerge as dm
import numpy as np
import shutil as st
filePathCT = 'ALL5S'
filePathSeq = 'SEQ'
def DataCreate():
    nameListCT = dm.EachFile(filePathCT)  # 获得所给路径下所有文件的名字列表
    nameListSeq = dm.EachFile(filePathSeq)
    count = 0
    if(nameListCT[0][0: -3] == nameListSeq[0][0: -4]):
        print("True")
    else:
        print("False")
    for i in range(len(np.array(nameListCT))):
        nameCT = nameListCT[i][0: -3]
        for j in range(len(np.array(nameListSeq))):
            nameSeq = nameListSeq[j][0: -4]
            if(nameSeq == nameCT):
                count += 1
                print("&&&")
                print(nameListCT[i])
                print(nameListSeq[j])
                print(count)
                print("%%%%")
                seqPath = dm.FileNmae(filePathSeq, nameListSeq[j])
                #st.move(ctPath, 'CT')
                st.move(seqPath, 'All5sSeq')
                break
    '''for i in range(len(nameList)):
        if(i in idx):
            ctPath = dm.FileNmae(filePath, nameList[i])
            st.move(ctPath, 'ArchivellTestData')
        else:
            ctPath = dm.FileNmae(filePath, nameList[i])
            st.move(ctPath, 'ArchivellTrainData')
    print(len(nameList))
    #print(nameSize)'''
DataCreate()