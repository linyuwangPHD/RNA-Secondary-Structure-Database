import DataMerge as dm
import numpy as np
import shutil as st

filePath = 'Fourth/Validation/TrainData-Validation/TrainData'
def DataCreate():
    nameList = dm.EachFile(filePath)  # 获得所给路径下所有文件的名字列表
    nameSize = int(len(nameList) * 0.1)
    print(nameSize)
    idx = np.random.choice(len(nameList), size=211, replace=False)
    for i in range(len(nameList)):
        if(i in idx):
            ctPath = dm.FileNmae(filePath, nameList[i])
            st.move(ctPath, 'Fourth/Validation/TrainData-Validation/Ninth')
        #else:
        #    ctPath = dm.FileNmae(filePath, nameList[i])
        #    st.copy(ctPath, 'Fourth/TrainData')
    print(len(nameList))
DataCreate()