import os, sys
def EachFile(filepath):#filepath文件存储路径
    pathDir = os.listdir(filepath) #读取文件存储路径下的所有文件，并返回一个由文件名字组成的list
    return pathDir #返回 有文件名字组成的list
def FileNmae(filepath, file):#filepath文件存储路径, file为文件名字
    return filepath + '/' + file #返回文件的绝对路径（在存储路径基础上加上文件名）