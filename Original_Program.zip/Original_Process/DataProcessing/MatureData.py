import DataMerge as dm
import numpy as np
import shutil as st
filePath = 'Fourth/FourthData'

def DataCreate():
    count = 0
    nameList = dm.EachFile(filePath)  # 获得所给路径下所有文件的名字列表
    file_handle = open('Fourth/FourthfamilyNoRe.fasta', mode='r')
    line = file_handle.readline()
    while(line):
        if(line[0] == '>'):
            #print(line[1:-1])
            for i in range(0, len(np.array(nameList))):

                if(nameList[i] == line[1: -1]):
                    print(line[1: -1])
                    print("%%%%%%%")
                    count += 1
                    print(nameList[i])
                    print(line[1: -1])
                    ctPath = dm.FileNmae(filePath, nameList[i])
                    st.copy(ctPath, 'Fourth/NoReDouncany')
                    print("%%%%")
                    print(count)
                    break
        line = file_handle.readline()

DataCreate()