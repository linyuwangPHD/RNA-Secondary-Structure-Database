import DataMerge as dm
import numpy as np
import shutil as st
filePathCT = 'mfold5s'
filePathSeq = 'm5sData'

def DataCreate():
    nameListmfold = dm.EachFile(filePathCT)  # 获得所给路径下所有文件的名字列表
    nameListTest = dm.EachFile(filePathSeq)
    PPV = 0
    Sen = 0
    Count = 0

    for i in range(len(np.array(nameListmfold))):
        AllPre = 0
        TruePre = 0
        All = 0
        for j in range(len(np.array(nameListTest))):
            if(nameListTest[j] == nameListmfold[i]):
                Count += 1
                flag = True
                mfoldPath = dm.FileNmae(filePathCT, nameListmfold[i])
                testPath = dm.FileNmae(filePathSeq, nameListTest[i])
                filefold = open(mfoldPath, mode='r')
                filetest = open(testPath, mode='r')
                linefold = filefold.readline()
                linefold = filefold.readline()
                lineTest = filetest.readline()
                lineTest = filetest.readline()
                while(lineTest):
                    if(linefold.split()[-1] != '0' and int(linefold.split()[-2]) > int(linefold.split()[0])):
                        AllPre += 1
                        if(linefold.split()[-2] == lineTest.split()[-2] ):
                            TruePre += 1
                    if(int(lineTest.split()[-2]) > int(lineTest.split()[0])):
                        All += 1
                    lineTest = filetest.readline()
                    linefold = filefold.readline()
        print("%%%%%%%")
        if(AllPre != 0 and All != 0):
            print(TruePre/AllPre)
            print(TruePre/All)
            PPV += TruePre/AllPre
            Sen += TruePre/All
    print("&&&&&&&&&&&&&&&")
    print(PPV/Count)
    print(Sen/Count)
    print(Count)

    '''for i in range(len(nameList)):
        if(i in idx):
            ctPath = dm.FileNmae(filePath, nameList[i])
            st.move(ctPath, 'ArchivellTestData')
        else:
            ctPath = dm.FileNmae(filePath, nameList[i])
            st.move(ctPath, 'ArchivellTrainData')
    print(len(nameList))
    #print(nameSize)'''
DataCreate()