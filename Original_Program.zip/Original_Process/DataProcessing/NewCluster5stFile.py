import DataMerge as dm
import numpy as np
import shutil as st
filePathCT = 'CT'

def DataCreate():
    nameListCT = dm.EachFile(filePathCT)  # 获得所给路径下所有文件的名字列表
    file_handle = open('MaAture5stData.fasta', mode='r')
    line = file_handle.readline()
    while(line):
        if(line[0] == '>'):
            count = 0
            erar = 2
            while(count < len(line)):
                if(line[count] == '-'):
                    count += 1
                    break
                count += 1
            while(erar < len(line)):
                if (line[erar] == 't' and line[erar-1] == 'c' and  line[erar-2] == '.'):
                    erar += 1
                    break
                erar += 1
            strName = line[count: erar]
            for i in range(len(np.array(nameListCT))):
                nameCT = nameListCT[i]
                if(nameCT == strName):
                    seqPath = dm.FileNmae(filePathCT, nameListCT[i])
                    st.move(seqPath, '5stClusterCT')
                    break
        line = file_handle.readline()
DataCreate()