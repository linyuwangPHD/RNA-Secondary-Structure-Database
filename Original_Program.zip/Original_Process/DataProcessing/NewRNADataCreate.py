import numpy as np
import DataMerge as dm
import h5py as h5
filePath = 'AllBpTrainData'
def DataCreate():
    nameList = dm.EachFile(filePath)  # 获得所给路径下所有文件的名字列表
    SeqList = []  # 定义序列列表list,用于存储RNA序列信息
    StrList = []  # 定义结构List,用于存储RNA是否配对信息
    StruetureList = [] # 用于存储RNA结构类型信息
    PriList = []
    FileIndex = []
    numLength = 300 # 当RNA序列大于三百时， 用于添加到长度序列中
    Length = []  # 定于序列长度List, 用于存储每个数据的长度
    for ctName in range(len(nameList)): # 循环遍历路径下所有文件
        print("^%%%%%%")
        print(ctName)
        Pri = []
        List = [] # 用来存储每个文件中的数据
        Seq = []  # 用于存储某一文件的序列
        Structure = []  # 用于存储某一文件的结构,存储序列配对信息
        StrListAll = [] # 用于存储某一文件的结构，存储结构类型信息
        ctPath = dm.FileNmae(filePath, nameList[ctName])  # 调用FileName方法获得当前读取文件的绝对路径
        fileRead = open(ctPath, mode='r', encoding='UTF-8')  # 打开当前文件，准备读取文件内容
        line = fileRead.readline()  # 一行一行读取文件
        while line and line.split()[0] != '1':  # 把每个文件的头几行非数据行读过
            line = fileRead.readline()
        while line:  # 读取数据中的每一行并把数据的每一行依次加入List中
            if (len(line.split()) == 3):
                list = [line.split()[0], line.split()[1], line.split()[2], 0]
                List.append(list)  # 将文件中的序列号信息， 碱基信息， 配对信息和结构类型信息
            line = fileRead.readline()  # 读取文件的下一行
        List = np.array(List)  # 将List类型转化为numpy数组类型
        flag = -1  # 用来存储当前标记的位置，若为-1则不存在标记位置
        Stack = []  # 用来存储标记位置的栈结构
        for i in range(len(List)):  # 遍历List进行数据的第一层处理
            if (i == flag):  # 当遍历位置等于标记位置时
                Stack.pop()  # 栈数据出栈
                if (not Stack):  # 若此时栈为空则flag赋值为-1
                    flag = -1
                else:
                    flag = Stack[-1]  # 否则flag赋值为栈顶元素
            if (List[i][2] != '0' and int(List[i][0]) < int(List[i][2]) and List[i][3] == '0' and int(List[i][2]) < len(
                    List)):  # 当数据存在配对信息并且序号信息小于配对信息并且未被处理
                if (flag < 0):  # 若flag<0，则当前不存在标记位置
                    List[i][3] = '1'  # 当前行的第四个元素赋值为‘1'
                    List[int(List[i][2]) - 1][3] = '2'  # 配对行的第四个元素赋值为‘2’
                    flag = int(List[i][2]) - 1  # 标记位置赋值为int(List[i][2])-1
                    Stack.append(int(List[i][2]) - 1)  # 将int(List[i][2])-1压栈
                else:  # 当flag不小于0时
                    if (int(List[i][2]) - 1 < flag):  # 配对位置小于flag时
                        List[i][3] = '1'  # 当前行的第四个元素赋值为‘1'
                        List[int(List[i][2]) - 1][3] = '2'  # 配对行的第四个元素赋值为‘2’
                        flag = int(List[i][2]) - 1  # 标记位置赋值为int(List[i][2])-1
                        if (Stack[-1] == int(List[i][2])):
                            Stack.pop()  # 若当前标记位置与上一个标记位置是连续的则出栈
                        Stack.append(int(List[i][2]) - 1)  # # 将int(List[i][2])-1压栈
        flag = -1
        Stack = []
        for i in range(len(List)):
            if (i == flag):
                Stack.pop()
                if (not Stack):
                    flag = -1
                else:
                    flag = Stack[-1]
            if (List[i][2] != '0' and int(List[i][0]) < int(List[i][2]) and List[i][3] == '0' and int(List[i][2]) < len(
                    List)):
                if (flag < 0):
                    List[i][3] = '3'
                    List[int(List[i][2]) - 1][3] = '4'
                    flag = int(List[i][2]) - 1
                    Stack.append(int(List[i][2]) - 1)
                else:
                    if (int(List[i][2]) - 1 < flag):
                        List[i][3] = '3'
                        List[int(List[i][2]) - 1][3] = '4'
                        flag = int(List[i][2]) - 1
                        if (Stack[-1] == int(List[i][2])):
                            Stack.pop()
                        Stack.append(int(List[i][2]) - 1)
        for i in range(len(List)):
            if (List[i][2] != '0' and int(List[i][0]) < int(List[i][2]) and List[i][3] == '0' and int(List[i][2]) < len(
                    List)):
                List[i][3] = '5'
                List[int(List[i][2]) - 1][3] = '6'
        if(len(List)<= 300):
            Length.append(len(List))
            FileIndex.append(ctName)
            for i in range(len(List)):
                if (List[i][1] == 'A' or List[i][1] == 'a'):
                    Seq.append([1, 0, 0, 0, 0, 0, 0, 1, 0])
                    Pri.append([int(List[i][0]), 1, int(List[i][2])])
                elif (List[i][1] == 'U' or List[i][1] == 'u'):
                    Seq.append([0, 0, 1, 0, 0, 1, 1, 0, 0])
                    Pri.append([int(List[i][0]), 2, int(List[i][2])])
                elif (List[i][1] == 'G' or List[i][1] == 'g'):
                    Seq.append([0, 1, 0, 0, 0, 0, 0, 1, 1])
                    Pri.append([int(List[i][0]), 3, int(List[i][2])])
                elif (List[i][1] == 'C' or List[i][1] == 'c'):
                    Seq.append([0, 0, 0, 1, 0, 0, 1, 0, 0])
                    Pri.append([int(List[i][0]), 4, int(List[i][2])])
                else:
                    Seq.append([0, 0, 0, 0, 1, 0, 0, 0, 0])
                    Pri.append([int(List[i][0]), 10, int(List[i][2])])
                if (List[i][2] == '0'):
                    Structure.append([1, 0])
                else:
                    Structure.append([0, 1])
                if(List[i][3] == '0'):
                    StrListAll.append([0,0,0,1,0,0,0])
                elif(List[i][3] == '1'):
                    StrListAll.append([1,0,0,0,0,0,0])
                elif(List[i][3] == '2'):
                    StrListAll.append([0,0,0,0,0,0,1])
                elif(List[i][3] == '3'):
                    StrListAll.append([0,1,0,0,0,0,0])
                elif(List[i][3] == '4'):
                    StrListAll.append([0,0,0,0,0,1,0])
                elif(List[i][3] == '5'):
                    StrListAll.append([0,0,1,0,0,0,0])
                else:
                    StrListAll.append([0,0,0,0,1,0,0])
            for j in range(len(List), 300):  # 当序列长度不够300时，在列表末尾出补0
                Seq.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
                Structure.append([0, 0])
                StrListAll.append([0, 0, 0, 0, 0, 0, 0])
                Pri.append([0, 0 ,0])
            SeqList.append(Seq)
            StrList.append(Structure)
            StruetureList.append(StrListAll)
            PriList.append(Pri)
        else:
            count = 0
            while (len(List) - count * 100 > 300):
                Seq = []  # 用于存储某一文件的序列
                Structure = []  # 用于存储某一文件的结构
                StrListAll = []
                Pri = []
                Length.append(numLength)
                FileIndex.append(ctName)
                for i in range(count * 100, count * 100 + 300):  # 遍历List中的每一个数据，把序列数据转化并添加到Seq中，把结构数据转化并添加到Structure中
                    medPri = []
                    medPri.append(int(List[i][0]))
                    if (List[i][1] == 'A' or List[i][1] == 'a'):
                        Seq.append([1, 0, 0, 0, 0,0, 0, 1, 0])
                        medPri.append(1)
                    elif (List[i][1] == 'U' or List[i][1] == 'u'):
                        Seq.append([0, 0, 1, 0, 0, 1, 1, 0, 0])
                        medPri.append(2)
                    elif (List[i][1] == 'G' or List[i][1] == 'g'):
                        Seq.append([0, 1, 0, 0, 0, 0, 0, 1, 1])
                        medPri.append(3)
                    elif(List[i][1] == 'C' or List[i][1] == 'c'):
                        Seq.append([0, 0, 0, 1, 0, 0, 1, 0, 0])
                        medPri.append(4)
                    else:
                        Seq.append([0, 0, 0, 0, 1, 0, 0, 0, 0])
                        medPri.append(10)
                    medPri.append(int(List[i][2]))
                    Pri.append(medPri)
                    if (List[i][2] == '0'):
                        Structure.append([1, 0])
                    else:
                        Structure.append([0, 1])
                    if (List[i][3] == '0'):
                        StrListAll.append([0, 0, 0, 1, 0, 0, 0])
                    elif (List[i][3] == '1'):
                        StrListAll.append([1, 0, 0, 0, 0, 0, 0])
                    elif (List[i][3] == '2'):
                        StrListAll.append([0, 0, 0, 0, 0, 0, 1])
                    elif (List[i][3] == '3'):
                        StrListAll.append([0, 1, 0, 0, 0, 0, 0])
                    elif (List[i][3] == '4'):
                        StrListAll.append([0, 0, 0, 0, 0, 1, 0])
                    elif (List[i][3] == '5'):
                        StrListAll.append([0, 0, 1, 0, 0, 0, 0])
                    else:
                        StrListAll.append([0, 0, 0, 0, 1, 0, 0])
                count += 1
                SeqList.append(Seq)  # 把每个文件的序列添加到序列list中
                StrList.append(Structure)  # 把每个文件的结构添加到结构list中
                StruetureList.append(StrListAll)
                PriList.append(Pri)
            Length.append(len(List) - count * 100)
            FileIndex.append(ctName)
            Seq = []  # 用于存储某一文件的序列
            Structure = []  # 用于存储某一文件的结构
            StrListAll = []
            Pri = []
            for i in range(count * 100, len(List)):  # 遍历List中的每一个数据，把序列数据转化并添加到Seq中，把结构数据转化并添加到Structure中
                medPri = []
                medPri.append(int(List[i][0]))
                if (List[i][1] == 'A' or List[i][1] == 'a'):
                    Seq.append([1, 0, 0, 0, 0, 0, 0, 1, 0])
                    medPri.append(1)
                elif (List[i][1] == 'U' or List[i][1] == 'u'):
                    Seq.append([0, 0, 1, 0, 0, 1, 1, 0, 0])
                    medPri.append(2)
                elif (List[i][1] == 'G' or List[i][1] == 'g'):
                    Seq.append([0, 1, 0, 0, 0, 0, 0, 1, 1])
                    medPri.append(3)
                elif (List[i][1] == 'C' or List[i][1] == 'c'):
                    Seq.append([0, 0, 0, 1, 0, 0, 1, 0, 0])
                    medPri.append(4)
                else:
                    Seq.append([0, 0, 0, 0, 1, 0, 0, 0, 0])
                    medPri.append(10)
                medPri.append(int(List[i][2]))
                Pri.append(medPri)
                if (List[i][2] == '0'):
                    Structure.append([1, 0])
                else:
                    Structure.append([0, 1])
                if (List[i][3] == '0'):
                    StrListAll.append([0, 0, 0, 1, 0, 0, 0])
                elif (List[i][3] == '1'):
                    StrListAll.append([1, 0, 0, 0, 0, 0, 0])
                elif (List[i][3] == '2'):
                    StrListAll.append([0, 0, 0, 0, 0, 0, 1])
                elif (List[i][3] == '3'):
                    StrListAll.append([0, 1, 0, 0, 0, 0, 0])
                elif (List[i][3] == '4'):
                    StrListAll.append([0, 0, 0, 0, 0, 1, 0])
                elif (List[i][3] == '5'):
                    StrListAll.append([0, 0, 1, 0, 0, 0, 0])
                else:
                     StrListAll.append([0, 0, 0, 0, 1, 0, 0])
            for j in range(len(List) - count * 100, 300):  # 当序列长度不够300时，在列表末尾出补0
                Seq.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
                Structure.append([0, 0])
                StrListAll.append([0, 0, 0, 0, 0, 0, 0])
                Pri.append([0, 0, 0, 0, 0, 0, 0])
            SeqList.append(Seq)  # 把每个文件的序列添加到序列list中
            StrList.append(Structure)  # 把每个文件的结构添加到结构list中
            StruetureList.append(StrListAll)
            PriList.append(Pri)
    return np.array(SeqList), np.array(StrList), np.array(Length), np.array(StruetureList), np.array(PriList), np.array(FileIndex) # 返回序列、结构和长度的List
def AllDataWrite(): # 将处理好的数据存储为h5文件
    SeqList, StrList, Length, StructureList, PriList, FileIndex = DataCreate() # 获得已经处理好的数据
    print(SeqList.shape)
    print(StrList.shape)
    print(Length.shape)
    print(StructureList.shape)
    print(PriList.shape)
    print(FileIndex.shape)
    AllDataFile = h5.File('AllBpMatrix/AllTrainData.h5', 'w') # 创建h5文件并标记为写文件
    AllDataFile.create_dataset('SeqList', data=SeqList)
    AllDataFile.create_dataset('FairList', data=StrList)
    AllDataFile.create_dataset('Length', data=Length)
    AllDataFile.create_dataset('StructureList', data=StructureList)
    AllDataFile.create_dataset('PriList', data=PriList)
    AllDataFile.create_dataset('FileIndex', data=FileIndex)
    AllDataFile.close()
AllDataWrite()





