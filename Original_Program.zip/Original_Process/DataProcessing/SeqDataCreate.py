import DataMerge as dm
import numpy as np
import shutil as st
filePath =  'All5sSeq'

def DataCreate():
    count = 0
    nameList = dm.EachFile(filePath)  # 获得所给路径下所有文件的名字列表
    file_handle = open('ALL5S.fasta', mode='w')
    for i in range(0, len(np.array(nameList))): #len(nameList)):
        count += 1
        name = "> "+nameList[i][0:-3] + 'ct'
        DataPath = dm.FileNmae(filePath, nameList[i])
        fileRead = open(DataPath, mode='r', encoding='UTF-8')
        line = fileRead.readline()
        line = fileRead.readline()
        line = fileRead.readline()
        print("%%")
        print(count)
        print(name)
        print(line[0: -2])
        file_handle.write(name+'\n')
        file_handle.write(line[0: -2] + '\n')
        if(i != len(np.array(nameList))-1):
            file_handle.write('\n')

DataCreate()