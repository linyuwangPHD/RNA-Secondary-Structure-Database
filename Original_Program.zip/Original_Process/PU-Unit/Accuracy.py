import h5py as h5
import tensorflow as tf
import numpy as np
'''PriTestFile = h5.File('TenCross/First/TestDataNo10.h5', 'r')  # 建立读取测试文件数据
PriTestStructureList = PriTestFile['StructureList'][:]  # 读取测试的结构数据
PreSecStructureTest = h5.File('TenCross/First/Secondary5stStrTestPre5s.h5', 'r')  # 建立读取测试数据的预测结构信息文件
PreStructureTest = PreSecStructureTest['PreStructure'][:]  # 读取测试数据的预测结构信息
count = 0
Acc = 0
sess = tf.Session()
PriTestStructureList = np.reshape(PriTestStructureList, [-1, 3])
PreStructureTest = np.reshape(PreStructureTest, [-1, 3])
PriTestStructureList = tf.argmax(PriTestStructureList, 1)
PreStructureTest = tf.argmax(PreStructureTest, 1)
PriTestStructureList = sess.run(PriTestStructureList)
PreStructureTest = sess.run(PreStructureTest)
for i in range(13905):
        count += 1
        if(PriTestStructureList[i] == PreStructureTest[i]):
            Acc += 1
print(Acc)
print(count)
print(Acc/count)
print(PriTestStructureList.shape)
print(PreStructureTest.shape)'''



num = 28*27*26*25*24

nn = 5*4*3*2*1
print(num)
print(nn)
print(num/nn)
