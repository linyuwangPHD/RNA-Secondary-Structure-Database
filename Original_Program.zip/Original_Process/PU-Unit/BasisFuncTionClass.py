import h5py as h5
import numpy as np
import tensorflow as tf
import itertools as it
import copy as cy
class BasisFunction:
    def DataIntercep(self, PreStructure, PriList, Length):  # 由于每个数据都被填充到了长度为135的数据，该方法是根据数据的真实长度把填充的部分截除掉
        PreStructure = PreStructure[0:Length, :] # 取预测结构数据的第0-Length项
        PriList = PriList[0:Length, :]   # 取真实结构的第0-Length项
        # 将处理的数据返回
        return PreStructure, PriList   # 数据类型均为<class 'numpy.ndarray'>
    def ConvergeToPri(self,  PreStructure):  # 将预测结构数据转化为[0, 1, 2]格式数据
        PreStructure = tf.argmax(PreStructure, 1) # 获得结构数据每行的最大位置处
        sess = tf.Session()  # 使用Session运行tensorflow矩阵
        PreStructure = sess.run(PreStructure)  # 使用Session运行tensorflow矩阵, 获得结构矩阵格式为[0, 1, 1, 2,2, 4, 5,6, 3]
        PreStructureList = []
        for i in range(len(PreStructure)):   # 遍历整个配对向量
            if (PreStructure[i] == 0):   # 当PreStructure值为3时， 将0添加到PreStructureList中
                PreStructureList.append(1)
            elif (PreStructure[i] == 6): # 当PreStructure值为0时， 将1添加到PreStructureList中
                PreStructureList.append(2)
            elif (PreStructure[i] == 1):  # 当PreStructure值为6时， 将2添加到PreStructureList中
                PreStructureList.append(3)
            elif (PreStructure[i] == 5):  # 当PreStructure值为6时， 将2添加到PreStructureList中
                PreStructureList.append(4)
            elif (PreStructure[i] == 2):  # 当PreStructure值为6时， 将2添加到PreStructureList中
                PreStructureList.append(5)
            elif (PreStructure[i] == 4):  # 当PreStructure值为6时， 将2添加到PreStructureList中
                PreStructureList.append(6)
            else:
                PreStructureList.append(0)
        return PreStructureList    # 类型为<class 'list'>
    def CreateStructureStack(self, PreStructure):  # 分层次创造配对区域的栈
        flag = False  # 用于标记前一个位置是否为1或者2
        ResultStack = []  # 用于存储茎区组合
        FirstLayerStack = []
        SecondaryLayerStack = []
        ThirdLarerStack = []
        MedStack = []  # 存储茎区组合的中间列表
        count = -1
        for i in range(len(PreStructure)):  # 遍历预测茎区的所有长度
            if (PreStructure[i] != 0):  # 当茎区遍历值为1时
                if (flag == False):  # 若此时标记为零
                    MedStack.append(i)  # 此时为茎区起始位置，
                    flag = True  # 并将标记修改为True
                if (i == len(PreStructure) - 1):  # 若当前位置为列表最后位置
                    count += 1
                    MedStack.append(i)  # 将当前位置记录为茎区结尾
                    MedStack.append(MedStack[1] - MedStack[0] + 1)  # 加入茎区长度
                    MedStack.append(PreStructure[i])  # 加入茎区标签
                    if(len(np.array(ResultStack)) != 0):
                        if(PreStructure[i] == ResultStack[-1][3]):
                            MedStack.append(MedStack[0] - ResultStack[-1][1]-1)
                        else:
                            MedStack.append(-1)  # 距前一个相同茎区长度为 -1
                    else:
                        MedStack.append(-1)  # 距前一个相同茎区长度为 -1
                    MedStack.append(0)  # 是否出栈信息
                    MedStack.append(count)  # 用于标记位置
                    MedStack.append(0)
                    ResultStack.append(MedStack)
                    MedStack = []
                    flag = False
                if(PreStructure[i] != PreStructure[i-1] and i>=1 and PreStructure[i-1] != 0):
                    count += 1
                    MedStack.append(i - 1)  # 将前一个1的位置加入MedStack作为茎区结尾
                    MedStack.append(MedStack[1] - MedStack[0] + 1)  # 加入茎区长度
                    MedStack.append(PreStructure[i - 1])  # 加入茎区标签
                    if (len(np.array(ResultStack)) != 0):
                        if (PreStructure[i - 1] == ResultStack[-1][3]):
                            MedStack.append(MedStack[0] - ResultStack[-1][1] - 1)
                        else:
                            MedStack.append(-1)  # 距前一个相同茎区长度为 -1
                    else:
                        MedStack.append(-1)  # 距前一个相同茎区长度为 -1
                    MedStack.append(0)  # 是否出栈信息
                    MedStack.append(count)  # 用于标记位置
                    MedStack.append(0)
                    ResultStack.append(MedStack)
                    MedStack = []
                    MedStack.append(i)  # 此时为茎区起始位置，
                    flag = True  # 并将标记修改为True
            else:  # 当标记不为1时候
                if (flag):  # 前面的数据为1
                    count += 1
                    MedStack.append(i - 1)  # 将前一个1的位置加入MedStack作为茎区结尾
                    MedStack.append(MedStack[1] - MedStack[0] + 1)  # 加入茎区长度
                    MedStack.append(PreStructure[i-1])  # 加入茎区标签
                    if (len(np.array(ResultStack)) != 0):
                        if (PreStructure[i-1] == ResultStack[-1][3]):
                            MedStack.append(MedStack[0] - ResultStack[-1][1] - 1)
                        else:
                            MedStack.append(-1)  # 距前一个相同茎区长度为 -1
                    else:
                        MedStack.append(-1)  # 距前一个相同茎区长度为 -1
                    MedStack.append(0)  # 是否出栈信息
                    MedStack.append(count)  # 用于标记位置
                    MedStack.append(0)
                    ResultStack.append(MedStack)
                    MedStack = []
                    flag = False
        for i in range(2):
            indexCount = 0
            for j in range(len(np.array(ResultStack))):
                if(i == 0):
                    if(ResultStack[j][3] == 1 or ResultStack[j][3] == 2):
                        FirstLayerStack.append(cy.deepcopy(ResultStack[j]))
                        FirstLayerStack[-1][7] = indexCount
                        indexCount += 1
                elif(i == 1):
                    if (ResultStack[j][3] == 3 or ResultStack[j][3] == 4):
                        SecondaryLayerStack.append(cy.deepcopy(ResultStack[j]))
                        SecondaryLayerStack[-1][7] = indexCount
                        indexCount += 1
                else:
                    if (ResultStack[j][3] == 5 or ResultStack[j][3] == 6):
                        ThirdLarerStack.append(cy.deepcopy(ResultStack[j]))
                        ThirdLarerStack[-1][7] = indexCount
                        indexCount += 1
        return ResultStack, FirstLayerStack, SecondaryLayerStack, ThirdLarerStack  # <class 'list'>类型
    def MatrixCreate(self, PriList, PreStructure):  # 根据真实的序列与结构信息与预测的结构信息，制作茎区矩阵
        Matrix = np.zeros(shape=[len(PriList), len(PriList)])  # 创建二维矩阵， 矩阵的长宽与PriList的长度相同，并将矩阵的所有值初始化为0，0表示未配对， 1表示配对
        for i in range(len(PriList)):
            for j in range(i, len(PriList)):
                # 由于在PriList中将RNA的四种碱基A、U、G、C分别制作为了1、2、3、4，而A-U、G-C、G-U均可配对，所以首先将矩阵上三角中行列绝对值差为1的标记为配对1
                if (abs(PriList[i][1] - PriList[j][1]) == 1 and abs(i - j) - 1 >= 2):
                    Matrix[i][j] = 1
        # 由于U-G配对时非常规配对，所以在一些茎区的边界处要将U-G配对解开
        for i in range(len(PriList)):
            for j in range(i, len(PriList)): # 遍历整个上三角矩阵
                if (Matrix[i][j] == 1 and ((PriList[i][1] == 2 and PriList[j][1] == 3) or (PriList[i][1] == 3 and PriList[j][1] == 2))): # 当前值为1，且行列值为2和3时候进入处理。
                    if (i == 0 or j == len(PriList) - 1 or (j - 1) <= i + 1): # 如果此时U-G配对在茎区的边界处，将 Matrix[i][j]配置为0
                        Matrix[i][j] = 0
                    else: # 当配对信息不在边界处时
                        if (Matrix[i - 1][j + 1] == 0 or Matrix[i + 1][j - 1] == 0):  # 如果G-U配对在茎区的尾部，将 Matrix[i][j]配置为0
                            Matrix[i][j] = 0
                    # 将修改为0的位置进行判断，若此时的PreStructure正好预测他们配对，则将Matrix[i][j]再次赋值为1
                    if ((PreStructure[i] == 1 and PreStructure[j] == 2) or ((PreStructure[i] == 2 and PreStructure[j] == 1))):
                        Matrix[i][j] = 1
        return Matrix  # 生成可以产生矩阵的所有茎区  # 数据类型均为<class 'numpy.ndarray'>
    def MaxStem(self, i, j, p, q, Matrix):  # 获取矩阵某一区域的全部茎区
        AllSterm = []  # 用于存放茎区的列表[i, j, p, q]
        IndexQ = q   # 定义下标IndexQ并将q赋值给IndexQ
        while (IndexQ >= p):  # 当IndexQ大于等于p时，进入循环
            if (IndexQ - p >= j - i): # 当IndexQ-p 大于等于j-i时，此时宽度大于高度，所以高度i,j的值不需要改变，由于茎区时从右上角下左下角寻找的，所以Q值不需要改变，此时需要改变P值是的q-p=j-i
                IndexI = i   # 将I值赋值给IndexI
                IndexJ = j  # 将J值赋值给IndexJ
                IndexP = IndexQ - (IndexJ - IndexI)  # 将新的p值赋值给IndexP
            else: #  若IndexQ-p 不大于j-i，此时高度大于宽度。所以宽度p,q不需要改变，由于茎区时从右上角下左下角寻找的，所以I值不需要改变，此时需要改变J值使的q-p=j-i
                IndexI = i  # 将i值赋值给IndexI
                IndexP = p  # 将p值赋值给IndexP
                IndexJ = IndexI + IndexQ - IndexP  # 将新的J值赋值给IndexJ
            count = 0   # 用来记录遍历茎区的长度
            MedQ = IndexQ   # 将IndexQ的值赋值为MedQ,
            MedI = IndexI   # 将IndexIde值赋值给MedI
            Indexj = IndexJ  # 将IndexJ的值赋值给Indexj
            flag = False    # 定义标签数据
            StemList = []  # 定义临时存储茎区的列表
            while (MedQ >= IndexP and MedI <= Indexj): # 当MedQ>=IndexP并且MedI <= Indexj时，即矩阵对角线还未遍历完
                if (Matrix[MedI][MedQ] == 1): # 若Matrix[MedI][MedQ] == 1，即MedI和MedQ碱基可以匹配
                    count += 1  # 此时茎区长度加1
                    if (MedQ == IndexP and MedI == Indexj):  # 若此时已经遍历到了矩阵边界
                        if (flag == False): #  若flag==False,证明当前节点是独立茎区节点
                            StemList.append(MedI)   # 此时将独立节点茎区添加到StenList茎区中
                            StemList.append(MedI)
                            StemList.append(MedQ)
                            StemList.append(MedQ)
                        else: # 若flag==True,证明当前节点不是独立茎区节点
                            StemList.insert(1, MedI)  # 此时的MedI为茎区的j， MedQ为茎区的p。将两者分别放在茎区的第2，3位置
                            StemList.insert(2, MedQ)
                        StemList.insert(4, count)
                        AllSterm.append(StemList) # 将临时茎区StenList添加到List中
                        StemList = []  # 将StemList赋值为[]
                        count = 0 # 并将count赋值为0

                    else: # 当MedQ与MedI没有遍历到边界时
                        if (flag == False):  # 若此时flag== False，证明该节点时茎区的起点。
                            StemList.append(MedI)  # 此时将MedI,与MedQ添加到StemList中
                            StemList.append(MedQ)
                            flag = True # 并将Flag赋值为True,证明茎区已经存在了节点
                else: # 当Matrix[MedI][MedQ] == 0
                    if (flag == True):  # 若此时的标签数据为True证明上一个节点为茎区的结尾
                        StemList.insert(1, MedI - 1)
                        StemList.insert(2, MedQ + 1)  # 将上一个节点添加到临时列表StemList中
                        flag = False   # 此时结束了一个茎区，将flag赋值为False
                        StemList.insert(4, count)
                        AllSterm.append(StemList)  # 将临时茎区添加到List中
                        StemList = []  #重新赋值StemList列表
                        count = 0 # 将长度值赋值为0
                MedQ -= 1 # MedQ减1， MedI加1.遍历访问对角线的其他节点
                MedI += 1
            IndexQ -= 1 # 换一条对角线继续访问
        IndexI = i + 1  # IndexI赋值为i+1。开始处理剩余对角线的茎区
        while (IndexI <= j):  # 当IndexI小于等于j时候进入茎区。
            if (q - p >= j - IndexI):  # 当q - p >= j - IndexI时，即宽度大于高度，此时i,j,q不需要修改，修改p值，使j-i == Q-p
                IndexJ = j   # j值赋值给IndexJ
                IndexQ = q  # q值赋值给IndexQ
                IndexP = IndexQ - (IndexJ - IndexI)  # IndexQ - (IndexJ - IndexI)赋值给IndexP使得q-p==j-
            else: # 当q - p < j - IndexI时，即高度大于宽度，此时i,p,q不需要修改，修改j值，使j-i == Q-p
                IndexQ = q  # 将q赋值给IndexQ
                IndexP = p  # 将p赋值给Indexp
                IndexJ = IndexI + IndexQ - IndexP   # IndexI + IndexQ - IndexP赋值给IndexJ使得j-i == Q-p
            count = 0
            MedQ = IndexQ
            MedI = IndexI
            Indexj = IndexJ
            flag = False
            StemList = []
            while (MedQ >= IndexP and MedI <= Indexj):
                if (Matrix[MedI][MedQ] == 1):
                    count += 1
                    if (MedQ == IndexP and MedI == Indexj):
                        if (flag == False):
                            StemList.append(MedI)
                            StemList.append(MedI)
                            StemList.append(MedQ)
                            StemList.append(MedQ)
                        else:
                            StemList.insert(1, MedI)
                            StemList.insert(2, MedQ)
                        StemList.insert(4, count)
                        AllSterm.append(StemList)
                        StemList = []
                        count = 0
                    else:
                        if (flag == False):
                            StemList.append(MedI)
                            StemList.append(MedQ)
                            flag = True

                else:
                    if (flag == True):
                        StemList.insert(1, MedI - 1)
                        StemList.insert(2, MedQ + 1)
                        flag = False
                        StemList.insert(4, count)
                        AllSterm.append(StemList)
                        StemList = []
                        count = 0
                MedQ -= 1
                MedI += 1
            IndexI += 1
        if(i == j and p == q):  # 当两个茎区长度均为1时候
            flag = True # flg赋值为True
        else: # 否则为False
            flag = False
        return AllSterm,  flag    # 均为<class 'list'>类型
    def SelectStem(self, AllStem, flag):  # 选择出符合条件的茎， 并按照茎区长度排序
        SelectStemList = []
        for i in range(len(np.array(AllStem))):
            if (flag):
                count = 1
            else:
                count = 2
            if (AllStem[i][4] >= count and AllStem[i][2] - AllStem[i][1] > 3):  # 选出长度大于Count间隔大于3个碱基的茎区
                SelectStemList.append(AllStem[i])
        SelectStemList = np.array(SelectStemList)
        if (len(np.array(SelectStemList)) != 0):
            SelectStemList = SelectStemList[np.lexsort(-SelectStemList.T)]
        return SelectStemList  # 数据类型为<class 'numpy.ndarray'>
    def CombinationSterm(self, layerSterm):  # 茎区组合优化方案
        Combination = []  # 用于存储最终的优化方案
        Med = []   # 定义中间层列表
        for i in range(len(np.array(layerSterm))):  # 生成所有长度的茎区左右
            listnum = list(it.combinations(layerSterm, i+1))   # 生成个数为i+1的茎区组合
            List = [] # 定义列表
            for j in range(len(np.array(listnum))):
                List.append(list(listnum[j]))  # 将生成的每一个listnum添加到List中
            if((i+1) > 1): #and i+1 < len(np.array(layerSterm))):  # 从2开始处理list中的数据，将不兼容的组合删除
                for p in range(len(np.array(List))):  # 遍历访问List中的所有茎区组合
                    flag = False
                    for q in range(i+1):  # 遍历当前最优茎区组合中的左右茎区
                        for r in range(q+1, i+1): # 若兼容则继续
                            if(List[p][q][3] < List[p][r][0] or List[p][r][3] < List[p][q][0] or (List[p][q][1]<List[p][r][0] and List[p][r][3]<List[p][q][2]) or (List[p][r][1]<List[p][q][0] and List[p][q][3]<List[p][r][2])):
                                continue
                            else:# 若不兼容则flag赋值为True
                                flag = True
                                break # 并结束循环
                        if(flag): # 若flag==True则当前茎区组合不满足条件，退出循环
                            break
                    if(flag): # 若flag==True则当前茎区组合不满足条件，则继续下一个List最优茎区组合
                        continue
                    else: #若flag== False则当前茎区组合满足条件，将茎区添加到Med列表中
                        Med.append(List[p])
            else:
                for p in range(len(np.array(List))):
                    Med.append(List[p])
        numList = []
        for i in range(len(np.array(Med))):
            num = 0
            for j in range(len(np.array(Med[i]))):
                num += Med[i][j][4]
            numList.append(num)
        largeNum = numList[0]
        for i in range(len(np.array(numList))):
            if(numList[i] > largeNum):
                largeNum = numList[i]
        for i in range(len(np.array(numList))):
            if(numList[i] == largeNum):
                Combination.append(Med[i])
        return Combination
    def LayerStermCom(self, SelectStemListSort, Combination):   # SelectStemListSort为排列好的茎区集合， Combination已经存在的优化茎区
        Position = 0    # Position赋值为0，用于遍历访问SelectStemListSort所有茎区，
        LayerSterm = [] # 用于存储层级茎区集合
        while(Position<len(SelectStemListSort)):   # Position小于len(SelectStemListSort)时，进行循环。
            num = SelectStemListSort[Position][4]  # 将当前茎区的长度赋值给num
            stem = []  # 定义临时茎区集合
            while(Position<len(SelectStemListSort)): # 当Position<len(SelectStemListSort)再次进入循环，此时将于长度于num茎区相同的茎区全部访问完
                if(SelectStemListSort[Position][4] == num):  # 若此时茎区的长度等于num
                    stem.append(SelectStemListSort[Position]) # 则将改茎区存储于临时列表stem中
                else: # 否则证明于num长度相同的茎区已经访问完毕，结束该次循环
                    LayerSterm.append(stem)  # 将处理好的stem茎区赋值给LayerSterm
                    break  # 并结束循环
                Position += 1  # Position 加1,继续循环
                if(Position == len(SelectStemListSort)):   # 当Position == len(SelectStemListSort)时，此时需要将stem茎区添加到LayerSterm中
                    LayerSterm.append(stem)
        LayerSterm = np.array(LayerSterm)  # 将LayerSterm格式转换为numpyarray格式
        for layer in range(len(LayerSterm)):  # 遍历访问LayerSterm的每一层数据
            NewComSterm = []  # 对应每一个最优方案定义一个最优组合
            layerSterm = LayerSterm[layer]  # 将第layer层的数据赋值给layerSterm
            if(len(np.array(Combination)) == 0):  # 当Combination的长度为0时， 表明此时不存在最优茎区
                Combination = self.CombinationSterm(layerSterm)   # 则将layerSterm传入LayerCombinations方法获得最优茎区组合。
            else:  # 若Combination长度不为0
                Combination = np.array(Combination)
                Combination = Combination.tolist()
                for i in range(len(np.array(Combination))):  # 遍历访问Combination的每一个最优茎区
                    Temlist = []  # 定义临时列表
                    for j in range(len(np.array(layerSterm))): # 遍历访问layerSterm中的每一个茎区
                        flag = False  # 定义标签数据并赋值为False
                        for p in range(len(np.array(Combination[i]))): # 遍历访问当前最优茎区组合中的每个茎区
                            if(Combination[i][p][3] < layerSterm[j][0] or layerSterm[j][3] < Combination[i][p][0] or (Combination[i][p][1]<layerSterm[j][0] and layerSterm[j][3]<Combination[i][p][2]) or (layerSterm[j][1]<Combination[i][p][0] and Combination[i][p][3]<layerSterm[j][2])):
                                continue   # 若layerSterm中的茎区与最优茎区组合中的每个茎区兼容，则继续循环
                            else:  # 若不兼容，则结束遍历访问当前最优茎区组合中的每个茎区
                                flag = True # flag赋值为True
                                break
                        if(flag == False): # 若flag==False证明当前layerSterm中的茎区与当前最优茎区组合兼容
                            Temlist.append(layerSterm[j])  # 将茎区添加到Temlist中
                    if(len(np.array(Temlist)) == 0):
                        NewComSterm.append(Combination[i])
                    else:
                        Tem = self.CombinationSterm(Temlist)   # 此时调用LayerCombinations方法，获得的最优茎区组合赋值给Tem
                        for num in range(len(np.array(Tem))):  # 并将Tem的最优茎区组合赋值给Med列表
                            TemCom = cy.deepcopy(Combination[i])
                            for nn in range(len(np.array(Tem[num]))):
                                TemCom.append(Tem[num][nn])
                            NewComSterm.append(cy.deepcopy(TemCom))
                numList = [] # 由于会产生多个最优茎区组合， 定义numList用于存储每个最优茎区组合的长度和
                for i in range(len(np.array(NewComSterm))):  # 遍历访问整个Med数据
                    num = 0 # 定义num用于记录最优茎区组合的长度和
                    for j in range(len(np.array(NewComSterm[i]))): # 遍历访问每一个最优茎区组合中的每个茎区
                        num += NewComSterm[i][j][4]  # 将每个茎区的长度添加到num中
                    numList.append(num)  # 将num的值添加到numList中
                largeNum = numList[0] # 寻找最大长度的茎区组合值
                for i in range(len(np.array(numList))):
                    if (numList[i] > largeNum):
                        largeNum = numList[i]
                Combination = []
                for i in range(len(np.array(numList))):
                    if (numList[i] == largeNum):
                        Combination.append(NewComSterm[i])  # 将最大长度的茎区组合值赋值添加到Combination
        return Combination
    def RateOfSterm(self, LocalOne, LocalTwo, OptimalStemList, PreStructure):  # 计算茎区使用率
        RateOne = 0
        RateTwo = 0
        for i in range(len(np.array(OptimalStemList))):
            for j in range(int(OptimalStemList[i][0]), int(OptimalStemList[i][1]) + 1):
                if (j >= LocalOne[0] and j <= LocalOne[1] and (PreStructure[j] == 1 or PreStructure[j] == 3 or PreStructure[j] == 5)):
                    RateOne += 1
        for i in range(len(np.array(OptimalStemList))):
            for j in range(int(OptimalStemList[i][2]), int(OptimalStemList[i][3]) + 1):
                if (j >= LocalTwo[0] and j <= LocalTwo[1] and (PreStructure[j] == 2 or PreStructure[j] == 4 or PreStructure[j] == 6)):
                    RateTwo += 1
        return (RateTwo / LocalTwo[2] + RateOne / LocalOne[2]) / 2
    def MatrixStermCreate(self, ResultStack, Matrix, PreStructureList):
        TwoSuccess = []  # 存储两个完全匹配的茎区
        for i in range(len(np.array(ResultStack))):
            if(ResultStack[i][3] == 1):
                continue
            else:
                IndexQ = ResultStack[i][1]
                IndexP = ResultStack[i][0]
                for j in range(i):
                    if (ResultStack[j][3] == 1):
                        IndexI = ResultStack[j][0]
                        IndexJ = ResultStack[j][1]  # +1
                        AllSterm, flag = self.MaxStem(IndexI, IndexJ, IndexP, IndexQ, Matrix)
                        SelectStemList = self.SelectStem(AllSterm,  flag)
                        if (len(SelectStemList) != 0):
                            OptimalStemList = self.LayerStermCom(SelectStemList, [])
                            numCount = 0
                            for num in range(len(np.array(OptimalStemList))):
                                Rate = self.RateOfSterm(ResultStack[j], ResultStack[i], OptimalStemList[num], PreStructureList)
                                if(Rate > numCount):
                                    numCount = Rate
                            if(numCount >=1  and  ResultStack[j][2] > 1 and ResultStack[i][2] > 1):
                                TwoSuccess.append(ResultStack[j])
                                TwoSuccess.append(ResultStack[i])
                            if(numCount != 1 and (numCount >= (1+ ResultStack[j][2]/ResultStack[i][2])/2 or numCount >= (1+ ResultStack[i][2]/ResultStack[j][2])/2)):
                                TwoSuccess.append(ResultStack[j])
                                TwoSuccess.append(ResultStack[i])
        TwoSuccess = np.array(TwoSuccess)
        if(len(np.array(TwoSuccess)) != 0): # 按照长度进行排序
            TwoSuccess = TwoSuccess[np.lexsort(TwoSuccess[:, ::-1].T)]

        Successfully = []
        for i in range(len(TwoSuccess)): # 去重
            if(i == len(TwoSuccess)-1):
                Successfully.append(TwoSuccess[i])
            else:
                if(TwoSuccess[i][0] != TwoSuccess[i +1][0]):
                    Successfully.append(TwoSuccess[i])
        return Successfully
    def StermFreeCom(self, Resultstack, num):
        listnum = list(it.combinations(Resultstack, num))  # 生成个数为i+1的茎区组合
        StermFreecom = []
        for i in range(len(np.array(listnum))):
            if (listnum[i][0][3] == 2 or listnum[i][-1][3] == 1):
                continue
            else:
                numOne = 0
                numTwo = 0
                TemOne = 0
                TemTwo = 0
                flag = False
                flagTwo = False
                for j in range(len(np.array(listnum[i]))):
                    if(listnum[i][j][2] != 2):
                        flagTwo = True
                    if(listnum[i][j][3] == 1):
                        if(TemTwo == 0):
                            TemOne += listnum[i][j][2]
                        else:
                            numOne += TemOne
                            numTwo += TemTwo
                            if(numOne < numTwo):
                                flag = True
                                break
                            else:
                                TemTwo = 0
                                TemOne = listnum[i][j][2]
                    if(listnum[i][j][3] == 2):
                        TemTwo += listnum[i][j][2]
                    if(j == len(np.array(listnum[i]))-1):
                        numOne += TemOne
                        numTwo += TemTwo
                        if(numOne < numTwo):
                            flag = True
                if(flag == False and numOne != 0 and numOne == numTwo and flagTwo == True):
                    StermFreecom.append(listnum[i])
        return StermFreecom
    def ListNumStermCreate(self, ResultStack, Matrix, PreStructureList):
        OptimalSterm = []
        for i in range(len(ResultStack)):
            if (ResultStack[i][3] == 1):
                continue
            else:
                IndexQ = ResultStack[i][1]
                IndexP = ResultStack[i][0]
                for j in range(i):
                    if (ResultStack[j][3] == 1):
                        IndexI = ResultStack[j][0]
                        IndexJ = ResultStack[j][1]  # +1
                        AllSterm, flag = self.MaxStem(IndexI, IndexJ, IndexP, IndexQ, Matrix)
                        SelectStemList = self.SelectStem(AllSterm, flag)
                        if (len(SelectStemList) != 0):
                            OptimalStemList = self.LayerStermCom(SelectStemList, [])
                            numCount = 0
                            for num in range(len(np.array(OptimalStemList))):
                                Rate = self.RateOfSterm(ResultStack[j], ResultStack[i], OptimalStemList[num],PreStructureList)
                                if (Rate > numCount):
                                    numCount = Rate
                            if ((numCount >= 1 and ResultStack[j][2] > 1 and ResultStack[i][2] > 1) or(numCount != 1 and (numCount >= (1 + ResultStack[j][2] / ResultStack[i][2]) / 2 or numCount >= (1 + ResultStack[i][2] / ResultStack[j][2]) / 2)) ):
                                OptimalSterm.append(OptimalStemList)
        return OptimalSterm
    def BasicCorrect(self, SuccessSterm, num, AllSterm, Matrix, PreStructureList):
        flag = False
        listnum = self.StermFreeCom(SuccessSterm, num)
        for i in range(len(np.array(listnum))):
            OptimalSterm = self.ListNumStermCreate(listnum[i], Matrix, PreStructureList)
            Sterm = []
            for numOne in range(len(np.array(OptimalSterm))):
                for j in range(len(np.array(OptimalSterm[numOne]))):
                    for num in range(len(np.array(OptimalSterm[numOne][j]))):
                        Sterm.append(OptimalSterm[numOne][j][num])
            if(len(np.array(Sterm)) != 0):
                SplitSterm = self.StermHeavyPair(Sterm)
                SplitSterm = np.array(SplitSterm)
                SplitSterm = SplitSterm[np.lexsort(-SplitSterm.T)]
                Combination = self.LayerStermCom(SplitSterm, [])
            else:
                Combination = []
            Prelength = 0
            for numTwo in range(len(np.array(listnum[i]))):
                if (listnum[i][numTwo][3] == 1):
                    Prelength += listnum[i][numTwo][2]
            StermLength = 0
            if(len(np.array(Combination)) != 0):
                for numThree in range(len(np.array(Combination[0]))):
                    StermLength += Combination[0][numThree][4]
            if(StermLength != Prelength or StermLength == 0):
                Combination = []
            else:
                flag = True
                for ii in range(len(np.array(Combination))):
                    for jj in range(len(np.array(Combination[ii]))):
                        AllSterm.append(Combination[ii][jj])
        return AllSterm, flag
    def RepairStack(self, ResultStack, Combination):   # 把完全匹配的茎区 去掉
        RepairStack = []
        Count = 0
        for i in range(len(np.array(ResultStack))):
            flag = False
            for j in range(len(np.array(Combination))):
                if((Combination[j][0] <= ResultStack[i][0] and Combination[j][1] >= ResultStack[i][0]) or (Combination[j][0] <= ResultStack[i][1] and Combination[j][1] >= ResultStack[i][1]) or (Combination[j][2] <= ResultStack[i][0] and Combination[j][3] >= ResultStack[i][0]) or (Combination[j][2] <= ResultStack[i][1] and Combination[j][3] >= ResultStack[i][1])):
                    flag = True
                    break
                else:
                    continue
            if(flag == False):
                RepairStack.append(cy.deepcopy(ResultStack[i]))
                if(len(np.array(RepairStack)) == 1):
                    RepairStack[-1][4] = -1
                else:
                    if(RepairStack[-1][3] == RepairStack[-2][3]):
                        RepairStack[-1][4] = RepairStack[-1][0] - RepairStack[-2][1] -1
                    else:
                        RepairStack[-1][4] = -1
                RepairStack[-1][-1] = Count
                Count += 1
        return RepairStack
    def StermHeavyPair(self, MergeSterm):  # 配对茎区去重[ 72.    73.   100.   101.     2]
        SplitSterm = []
        for i in range(len(np.array(MergeSterm)) - 1):
            flag = False
            for j in range(i + 1, len(np.array(MergeSterm))):
                if (MergeSterm[i][0] == MergeSterm[j][0] and MergeSterm[i][1] == MergeSterm[j][1] and MergeSterm[i][2] == MergeSterm[j][2] and MergeSterm[i][3] == MergeSterm[j][3]):
                    flag = True
                    break
                else:
                    continue
            if (flag == False):
                SplitSterm.append(MergeSterm[i])
            else:
                continue
        SplitSterm.append(MergeSterm[-1])
        return SplitSterm

    def RemoveAllTwo(self, AllSterm, SuccessSterm):
        Sterm = []
        for i in range(len(np.array(AllSterm))):
            flagOne = False
            flagTwo = False
            for j in range(len(np.array(SuccessSterm))):
                if (AllSterm[i][0] >= SuccessSterm[j][0] and AllSterm[i][1] <= SuccessSterm[j][1] and SuccessSterm[j][
                    2] != 2):
                    flagOne = True
                if (AllSterm[i][2] >= SuccessSterm[j][0] and AllSterm[i][3] <= SuccessSterm[j][1]):
                    if (SuccessSterm[j][2] != 2):
                        flagTwo = True
                    break
            if (flagOne or flagTwo):
                Sterm.append(AllSterm[i])
        return Sterm
    def CorrectSterm(self, SuccessSterm, Matrix, PreStructureList):
        TemSuccess = cy.deepcopy(SuccessSterm)
        Index = 2
        length = len(np.array(TemSuccess))
        AllSterm = []
        while(Index <= length and Index<=4):
            AllSterm, flag = self.BasicCorrect(TemSuccess, Index, AllSterm, Matrix, PreStructureList)
            if(flag):
                TemSuccess = self.RepairStack(TemSuccess, AllSterm)
                length = len(np.array(TemSuccess))
            Index += 1
        if(len(np.array(AllSterm)) != 0):
            AllSterm = self.StermHeavyPair(AllSterm)
            AllSterm = self.RemoveAllTwo(AllSterm, SuccessSterm) # 移除全2茎区
        AllSterm = np.array(AllSterm)
        if(len(np.array(AllSterm))!= 0):
            AllSterm = AllSterm[np.lexsort(-AllSterm.T)]
        Combination = self.LayerStermCom(AllSterm, [])
        return Combination

    # ******************************************Secondary Layer ********************************************************************
    def TmSecondaryMatrixStermCreate(self, ResultStack, Matrix, PreStructureList):
        AAllSterm = []
        for i in range(len(np.array(ResultStack))):
            if(ResultStack[i][3] == 1):
                continue
            else:
                IndexQ = ResultStack[i][1]
                IndexP = ResultStack[i][0]
                for j in range(i):
                    if (ResultStack[j][3] == 1):
                        IndexI = ResultStack[j][0]
                        IndexJ = ResultStack[j][1]  # +1
                        AllSterm, flag = self.MaxStem(IndexI, IndexJ, IndexP, IndexQ, Matrix)
                        SelectStemList = self.SelectStem(AllSterm,  flag)
                        StermLength = 0
                        if (len(SelectStemList) != 0):
                            OptimalStemList = self.LayerStermCom(SelectStemList, [])
                            for ii in range(len(np.array(OptimalStemList[0]))):
                                StermLength += OptimalStemList[0][ii][4]
                            numCount = 0
                            for num in range(len(np.array(OptimalStemList))):
                                if(ResultStack[j][2] > ResultStack[i][2]):
                                    lengthNum = ResultStack[j][3]
                                else:
                                    lengthNum = ResultStack[i][3]
                                SingleRate, _ = self.ScondarySingleRateOfSterm(ResultStack[j], ResultStack[i], OptimalStemList[num], PreStructureList, lengthNum)
                                if(SingleRate > numCount):
                                    numCount = SingleRate
                            if(numCount >= 1 and StermLength >= 5):
                                for iii in range(len(np.array(OptimalStemList))):
                                    for jjj in range(len(np.array(OptimalStemList[iii]))):
                                        AAllSterm.append(OptimalStemList[iii][jjj])
        AAllSterm = self.StermHeavyPair(AAllSterm)
        return AAllSterm
    def SecondaryMatrixStermCreate(self, ResultStack, Matrix, PreStructureList):
        TwoSuccess = []  # 存储两个完全匹配的茎区
        for i in range(len(np.array(ResultStack))):
            if(ResultStack[i][3] == 1):
                continue
            else:
                IndexQ = ResultStack[i][1]
                IndexP = ResultStack[i][0]
                for j in range(i):
                    if (ResultStack[j][3] == 1):
                        IndexI = ResultStack[j][0]
                        IndexJ = ResultStack[j][1]  # +1
                        AllSterm, flag = self.MaxStem(IndexI, IndexJ, IndexP, IndexQ, Matrix)
                        SelectStemList = self.SelectStem(AllSterm,  flag)
                        StermLength = 0
                        if (len(SelectStemList) != 0):
                            OptimalStemList = self.LayerStermCom(SelectStemList, [])
                            for ii in range(len(np.array(OptimalStemList[0]))):
                                StermLength += OptimalStemList[0][ii][4]
                            numCount = 0
                            for num in range(len(np.array(OptimalStemList))):
                                if(ResultStack[j][2] > ResultStack[i][2]):
                                    lengthNum = ResultStack[j][3]
                                else:
                                    lengthNum = ResultStack[i][3]
                                SingleRate, _ = self.ScondarySingleRateOfSterm(ResultStack[j], ResultStack[i], OptimalStemList[num], PreStructureList, lengthNum)
                                if(SingleRate > numCount):
                                    numCount = SingleRate
                            if(numCount >= 1):
                                for stermNum in range(len(np.array(OptimalStemList))):
                                    flagL = False
                                    for LNum in range(len(np.array(OptimalStemList[stermNum]))):
                                        if(OptimalStemList[stermNum][LNum][4] >= 4):
                                            flagL = True
                                            break
                                    if(flagL):
                                        for sNum in range(len(np.array(OptimalStemList[stermNum]))):
                                            TwoSuccess.append(OptimalStemList[stermNum][sNum])
        if(len(np.array(TwoSuccess))!= 0):
            Successfully = self.StermHeavyPair(TwoSuccess)
            Successfully = np.array(Successfully)
            Successfully =  Successfully[np.lexsort(-Successfully.T)]
        else:
            Successfully = []
        return Successfully
    def ThirdMatrixStermCreate(self, ResultStack, Matrix, PreStructureList):
        TwoSuccess = []  # 存储两个完全匹配的茎区
        for i in range(len(np.array(ResultStack))):
            if(ResultStack[i][3] == 1):
                continue
            else:
                IndexQ = ResultStack[i][1]
                IndexP = ResultStack[i][0]
                for j in range(i):
                    if (ResultStack[j][3] == 1):
                        IndexI = ResultStack[j][0]
                        IndexJ = ResultStack[j][1]  # +1
                        AllSterm, flag = self.MaxStem(IndexI, IndexJ, IndexP, IndexQ, Matrix)
                        SelectStemList = self.SelectStem(AllSterm,  flag)
                        StermLength = 0
                        if (len(SelectStemList) != 0):
                            OptimalStemList = self.LayerStermCom(SelectStemList, [])
                            numCount = 0
                            for num in range(len(np.array(OptimalStemList))):
                                if(ResultStack[j][2] > ResultStack[i][2]):
                                    lengthNum = ResultStack[j][3]
                                else:
                                    lengthNum = ResultStack[i][3]
                                SingleRate, Rate = self.ScondarySingleRateOfSterm(ResultStack[j], ResultStack[i], OptimalStemList[num], PreStructureList, lengthNum)
                                if(Rate > numCount):
                                    numCount = Rate
                            FlagSterm = False
                            for stermNum in range(len(np.array(OptimalStemList))):
                                for sNum in range(len(np.array(OptimalStemList[stermNum]))):
                                    if(OptimalStemList[stermNum][sNum][4] >= 3):
                                        FlagSterm = True
                                        break
                            if(FlagSterm and numCount >= 0.4):
                                for stermNum in range(len(np.array(OptimalStemList))):
                                    for sNum in range(len(np.array(OptimalStemList[stermNum]))):
                                        TwoSuccess.append(OptimalStemList[stermNum][sNum])
                            if(FlagSterm == False and numCount >= 0.6):
                                for stermNum in range(len(np.array(OptimalStemList))):
                                    for sNum in range(len(np.array(OptimalStemList[stermNum]))):
                                        TwoSuccess.append(OptimalStemList[stermNum][sNum])
        if(len(np.array(TwoSuccess))!= 0):
            Successfully = self.StermHeavyPair(TwoSuccess)
            Successfully = np.array(Successfully)
            Successfully =  Successfully[np.lexsort(-Successfully.T)]
        else:
            Successfully = []
        return Successfully
    def LimitValue(self, ResultStack, LengthNum, Sterm):
        ForeValue = -1
        EaerValue = -1
        if(LengthNum == 1):
            for i in range(len(np.array(ResultStack))):
                if(Sterm[0] >= ResultStack[i][0] and Sterm[1] <= ResultStack[i][1]):
                    ForeValue = ResultStack[i][0]
                    EaerValue = ResultStack[i][1]
                    return ForeValue, EaerValue
        else:
            for i in range(len(np.array(ResultStack))):
                if(Sterm[2] >= ResultStack[i][0] and Sterm[3] <= ResultStack[i][1]):
                    ForeValue = ResultStack[i][0]
                    EaerValue = ResultStack[i][1]
                    return ForeValue, EaerValue
        return ForeValue, EaerValue
    def SecondaryExtendStem(self, Matrix, OptimalSterm,LengthNum, ResultStack):
        MedOptimal = [] # 建立中间的最优茎区， [[83, 85, 90, 92, 3], [77, 80, 94, 97,4]]， 用于存储OptimalSterm中每个茎区延长后的茎区
        for numOne in range(len(np.array(OptimalSterm))): # 遍历OptimalSterm中的每个茎区并进行处理
            Tem = []  # 创建临时列表， 用于记录每个OptimalSterm延长后的茎区
            I = int(OptimalSterm[numOne][0])  # 将当前OptimalSterm中茎区的I值赋值给I
            J = int(OptimalSterm[numOne][1])  # 将当前OptimalSterm中茎区的J值赋值给J
            P = int(OptimalSterm[numOne][2])  # 将当前OptimalSterm中茎区的P值赋值给P
            Q = int(OptimalSterm[numOne][3])  # 将当前OptimalSterm中茎区的Q值赋值给Q
            ForeValue, EaerValue = self.LimitValue(ResultStack, LengthNum,OptimalSterm[numOne])
            if(LengthNum == 1):
                while(I > 0 and Q < len(np.array(Matrix))-1 and I >= ForeValue): # 处理当前茎区的右上方， 当茎区的右上方没有在矩阵Mat的边界时候
                    if(Matrix[I-1][Q + 1] == 1):  # 若此时Mat[I-1][Q+1]即沿着右上方延长一个节点的值为1
                        I -= 1  # 此时将I的值减1，Q的值加1
                        Q += 1
                    else:
                        break
                while(J < len(np.array(Matrix))-1 and P > 0 and J<= EaerValue): # 茎区向左下方延申，此时可能会于其他茎区的I-Q其冲突
                    if (Matrix[J+1][P-1] == 1):  # 若茎区向左下方延申一个节点的Mat[J+1][P-1]为1
                        J += 1  # 茎区正常延申
                        P -= 1
                    else:
                        break
            else:
                while (I > 0 and Q < len(np.array(Matrix)) - 1 and Q <= EaerValue):  # 处理当前茎区的右上方， 当茎区的右上方没有在矩阵Mat的边界时候
                    if (Matrix[I - 1][Q + 1] == 1):  # 若此时Mat[I-1][Q+1]即沿着右上方延长一个节点的值为1
                        I -= 1  # 此时将I的值减1，Q的值加1
                        Q += 1
                    else:
                        break
                while (J < len(np.array(Matrix)) - 1 and P > 0 and P >= ForeValue):  # 茎区向左下方延申，此时可能会于其他茎区的I-Q其冲突
                    if (Matrix[J + 1][P - 1] == 1):  # 若茎区向左下方延申一个节点的Mat[J+1][P-1]为1
                        J += 1  # 茎区正常延申
                        P -= 1
                    else:
                        break
            Tem.append(I)   # 将延长后茎区的I添加到Tem列表中
            Tem.append(J)   # 将延长后茎区的J添加到Tem列表中
            Tem.append(P)   # 将延长后茎区的P添加到Tem列表中
            Tem.append(Q)  #  将延长茎区的Q添加到Tem列表中
            Tem.append(J-I + 1)  # 将延长后茎区的长度添加到Tem列表中
            MedOptimal.append(Tem)
        OptimalSterm = MedOptimal
        return OptimalSterm
    def ScondarySingleRateOfSterm(self, LocalOne, LocalTwo, OptimalStemList, PreStructure,LengthNum):  # 计算茎区使用率
        RateOne = 0
        RateTwo = 0
        for i in range(len(np.array(OptimalStemList))):
            for j in range(int(OptimalStemList[i][0]), int(OptimalStemList[i][1]) + 1):
                if (j >= LocalOne[0] and j <= LocalOne[1] and PreStructure[j] == 1):
                    RateOne += 1
        for i in range(len(np.array(OptimalStemList))):
            for j in range(int(OptimalStemList[i][2]), int(OptimalStemList[i][3]) + 1):
                if (j >= LocalTwo[0] and j <= LocalTwo[1] and PreStructure[j] == 2):
                    RateTwo += 1
        if(LengthNum == 1):
            return RateTwo / LocalTwo[2], (RateTwo / LocalTwo[2] + RateOne / LocalOne[2]) / 2
        else:
            return RateOne / LocalOne[2], (RateTwo / LocalTwo[2] + RateOne / LocalOne[2]) / 2
    def SingleRateOfSterm(self, LocalOne, LocalTwo, OptimalStemList, PreStructure,LengthNum):  # 计算茎区使用率
        RateOne = 0
        RateTwo = 0
        for i in range(len(np.array(OptimalStemList))):
            for j in range(int(OptimalStemList[i][0]), int(OptimalStemList[i][1]) + 1):
                if (j >= LocalOne[0] and j <= LocalOne[1] and PreStructure[j] == 1):
                    RateOne += 1
        for i in range(len(np.array(OptimalStemList))):
            for j in range(int(OptimalStemList[i][2]), int(OptimalStemList[i][3]) + 1):
                if (j >= LocalTwo[0] and j <= LocalTwo[1] and PreStructure[j] == 2):
                    RateTwo += 1
        if(LengthNum == 1):
            return RateOne / LocalOne[2], (RateTwo / LocalTwo[2] + RateOne / LocalOne[2]) / 2
        else:
            return RateTwo / LocalTwo[2], (RateTwo / LocalTwo[2] + RateOne / LocalOne[2]) / 2
    def SecondaryListNumStermCreate(self, ResultStack, Matrix, PreStructureList, LengthNum):
        OptimalSterm = []
        for i in range(len(ResultStack)):
            if (ResultStack[i][3] == 1):
                continue
            else:
                IndexQ = ResultStack[i][1]
                IndexP = ResultStack[i][0]
                for j in range(i):
                    if (ResultStack[j][3] == 1):
                        IndexI = ResultStack[j][0]
                        IndexJ = ResultStack[j][1]
                        AllSterm, flag = self.MaxStem(IndexI, IndexJ, IndexP, IndexQ, Matrix)
                        SelectStemList = self.SelectStem(AllSterm, flag)
                        SelectStemList = self.SecondaryExtendStem(Matrix, SelectStemList,LengthNum, ResultStack)
                        if(len(np.array(SelectStemList)) != 0):
                            SelectStemList = self.StermHeavyPair(SelectStemList)
                        if (len(SelectStemList) != 0):
                            OptimalStemList = self.LayerStermCom(SelectStemList, [])
                            numCount = 0
                            SingleCount = 0
                            for num in range(len(np.array(OptimalStemList))):
                                SingleRate, Rate = self.SingleRateOfSterm(ResultStack[j], ResultStack[i], OptimalStemList[num],PreStructureList, LengthNum)
                                if (Rate > numCount):
                                    numCount = Rate
                                if(SingleRate > SingleCount):
                                    SingleCount = SingleRate
                            if ((SingleCount >= 1) or(numCount != 1 and (numCount >= (1 + ResultStack[j][2] / ResultStack[i][2]) / 2 or numCount >= (1 + ResultStack[i][2] / ResultStack[j][2]) / 2)) ):
                                OptimalSterm.append(OptimalStemList)
        return OptimalSterm
    def SecondaryStermFreeCom(self, Resultstack, num):
        listnum = list(it.combinations(Resultstack, num))  # 生成个数为i+1的茎区组合
        StermFreeCom = []
        for i in range(len(np.array(listnum))):
            if (listnum[i][0][3] == 2 or listnum[i][-1][3] == 1):
                continue
            else:
                numOne = 0
                numTwo = 0
                flagTwo = False
                for j in range(len(np.array(listnum[i]))):
                    if (listnum[i][j][2] != 2):
                        flagTwo = True
                    if (listnum[i][j][3] == 1):
                        numOne += listnum[i][j][2]
                    if (listnum[i][j][3] == 2):
                        numTwo += listnum[i][j][2]
                if (numOne != 0 and numTwo != 0 and numOne != numTwo and flagTwo == True):
                    StermFreeCom.append(listnum[i])
        return StermFreeCom
    def SecondaryBasicCorrect(self, SuccessSterm, num, AllSterm, Matrix, PreStructureList):
        flag = False
        listnum = self.SecondaryStermFreeCom(SuccessSterm, num)
        for i in range(len(np.array(listnum))):
            One = 0
            Two = 0
            for NumTwo in range(len(np.array(listnum[i]))):
                if (listnum[i][NumTwo][3] == 1):
                    One += listnum[i][NumTwo][2]
            for NumTwoo in range(len(np.array(listnum[i]))):
                if (listnum[i][NumTwoo][3] == 2):
                    Two += listnum[i][NumTwoo][2]
            if(One > Two):
                LengthNum = 1
                GoalLength = One
            else:
                GoalLength = Two
                LengthNum = 2   # 获得长的一侧的值
            OptimalSterm = self.SecondaryListNumStermCreate(listnum[i], Matrix, PreStructureList, LengthNum)
            Sterm = []
            for numOne in range(len(np.array(OptimalSterm))):
                for j in range(len(np.array(OptimalSterm[numOne]))):
                    for num in range(len(np.array(OptimalSterm[numOne][j]))):
                        Sterm.append(OptimalSterm[numOne][j][num])
            if(len(np.array(Sterm)) != 0):
                SplitSterm = self.StermHeavyPair(Sterm)
                SplitSterm = np.array(SplitSterm)
                SplitSterm = SplitSterm[np.lexsort(-SplitSterm.T)]
                Combination = self.LayerStermCom(SplitSterm, [])
            else:
                Combination = []

            Prelength = 0
            if(LengthNum == 1):
                for numTwo in range(len(np.array(listnum[i]))):
                    if (listnum[i][numTwo][3] == 1):
                        Prelength += listnum[i][numTwo][2]
            else:
                for numTwoo in range(len(np.array(listnum[i]))):
                    if (listnum[i][numTwoo][3] == 2):
                        Prelength += listnum[i][numTwoo][2]
            StermLength = 0
            if(len(np.array(Combination)) != 0):
                for numThree in range(len(np.array(Combination[0]))):
                    StermLength += Combination[0][numThree][4]
            if(StermLength != Prelength or StermLength == 0 or GoalLength < 4):
                Combination = []
            else:
                flag = True
                for ii in range(len(np.array(Combination))):
                    for jj in range(len(np.array(Combination[ii]))):
                        AllSterm.append(Combination[ii][jj])
        return AllSterm, flag
    def SecondaryCorrectSterm(self, SuccessSterm, Matrix, PreStructureList, CombinationFist):
        TemSuccess = cy.deepcopy(SuccessSterm)
        Index = 2
        length = len(np.array(TemSuccess))
        AllSterm = []
        while(Index <= 4):
            AllSterm, flag = self.SecondaryBasicCorrect(TemSuccess, Index, AllSterm, Matrix, PreStructureList)
            if(flag):
                TemSuccess = self.RepairStack(TemSuccess, AllSterm)
                length = len(np.array(TemSuccess))
            Index += 1
        if(len(np.array(AllSterm)) != 0):
            AllSterm = self.StermHeavyPair(AllSterm)
            AllSterm = self.RemoveAllTwo(AllSterm, SuccessSterm) # 移除全2茎区
        CombinationSecondary = self.LayerStermCom(AllSterm, CombinationFist)
        return CombinationSecondary
    def ValueOfPPVSen(self, PriList, OptimalStemList):  # 计算PPV与Sen
        MedList = []
        ValueList = []
        AllPairs = 0
        TruePositive = 0
        FalsePositive = 0
        AllPredicPairs = 0
        ValurArray = np.zeros(shape=[len(PriList)])
        for i in range(len(OptimalStemList)):
            IndexI = OptimalStemList[i][0]
            IndexJ = OptimalStemList[i][1]
            IndexP = OptimalStemList[i][2]
            IndexQ = OptimalStemList[i][3]
            for j in range(int(IndexI), int(IndexJ + 1)):
                ValurArray[j] = OptimalStemList[i][3] - (j - IndexI) + 1
            count = 0
            while (IndexQ >= IndexP):
                ValurArray[int(IndexQ)] = OptimalStemList[i][0] + count + 1
                count += 1
                IndexQ -= 1
        for i in range(len(PriList)):
            MedList.append(PriList[i][0])
            MedList.append(PriList[i][1])
            MedList.append(PriList[i][2])
            MedList.append(ValurArray[i])
            ValueList.append(MedList)
            MedList = []
        ValueList = np.array(ValueList)
        for i in range(len(ValueList)):
            if (ValueList[i][2] != 0 and ValueList[i][2] > ValueList[i][0]):
                AllPairs += 1
            if (ValueList[i][3] != 0 and ValueList[i][3] > ValueList[i][0]):
                AllPredicPairs += 1
                if (ValueList[i][2] == ValueList[i][3]):
                    TruePositive += 1
                else:
                    FalsePositive += 1
        if (AllPredicPairs != 0 and AllPairs != 0):
            PPV = TruePositive / AllPredicPairs
            Sensitive = TruePositive / AllPairs
            if(PPV+Sensitive != 0):
                Fscore = 2*(PPV*Sensitive/(PPV+Sensitive))
            else:
                Fscore = 0
        return PPV, Sensitive, Fscore
    # ******************************************Secondary Layer ********************************************************************
    def SynCollection(self, PositionOne, ResultStack):   # 收集某一位置的组合大茎区
        CollectionSterm = []
        Index = PositionOne
        while (Index > 0):
            if (ResultStack[Index][4] <= 3 and ResultStack[Index][4] != -1):
                CollectionSterm.append(ResultStack[Index - 1])
            else:
                break
            Index -= 1
        CollectionSterm.reverse()
        CollectionSterm.append(ResultStack[PositionOne])
        for i in range(PositionOne + 1, len(np.array(ResultStack))):
            if (ResultStack[i][4] <= 3 and ResultStack[i][4] != -1):
                CollectionSterm.append(ResultStack[i])
            else:
                break
        return CollectionSterm
    def CollectionDoubleSterm(self, PositionOne, PositionTwo, ResultStack):  # 收集PositionOne与PositionTwo两个位置的大茎区
        CollectionSterm = []
        Med = []
        Index = PositionOne
        while (Index > 0):
            if (ResultStack[Index][4] <= 3 and ResultStack[Index][4] != -1):
                CollectionSterm.append(ResultStack[Index - 1])
            else:
                break
            Index -= 1
        CollectionSterm.reverse()
        CollectionSterm.append(ResultStack[PositionOne])
        for i in range(PositionOne + 1, PositionTwo):
            if (ResultStack[i][4] <= 3 and ResultStack[i][4] != -1):
                CollectionSterm.append(ResultStack[i])
            else:
                break
        Index = PositionTwo
        while (Index > PositionOne):
            if (ResultStack[Index][4] <= 3 and ResultStack[Index][4] != -1):
                Med.append(ResultStack[Index - 1])
            else:
                break
            Index -= 1
        Med.reverse()
        for i in range(len(np.array(Med))):
            CollectionSterm.append(Med[i])
        CollectionSterm.append(ResultStack[PositionTwo])
        for i in range(PositionTwo + 1, len(np.array(ResultStack))):
            if (ResultStack[i][4] <= 3 and ResultStack[i][4] != -1):
                CollectionSterm.append(ResultStack[i])
            else:
                break
        return CollectionSterm
    def SynSterm(self, CollectionSterm): # 人工合成大茎区，CollectionSterm为收集到的茎区
        MedSynLargeSterm = [] # 用来存储中间节段茎区
        SynLargeSterm = []    # 用来存储最终的人工合成大茎区
        Index = len(np.array(CollectionSterm))-1  # 从茎区的最后一项开始操作，将茎区集合最后一项下标赋值非Index
        while(Index > 0): # 当Index大于0时，进入循环
            TemList = []  # 定义临时列表
            TemList.append(CollectionSterm[Index])  # 首先将CollectionSterm[Index]添加到临时列表中
            IndexNum = Index - 1
            while(IndexNum >= 0):
                if(CollectionSterm[Index][4] <= 3 and CollectionSterm[Index][4] != -1 and CollectionSterm[Index][7] -1 == CollectionSterm[IndexNum][7]):
                    TemList.append(CollectionSterm[IndexNum])
                    Index -= 1
                    IndexNum -= 1
                else:
                    TemList.reverse()
                    MedSynLargeSterm.append(TemList)
                    if(IndexNum==0):
                        TemList = []
                        TemList.append(CollectionSterm[IndexNum])
                        MedSynLargeSterm.append(TemList)
                    break
                if(IndexNum < 0):
                    TemList.reverse()
                    MedSynLargeSterm.append(TemList)
                    break
            Index -= 1
        MedSynLargeSterm.reverse()
        for i in range(len(np.array(MedSynLargeSterm))):
            TemSyn = []
            count = 0
            for j in range(len(np.array(MedSynLargeSterm[i]))):
                count += MedSynLargeSterm[i][j][2]
                if(j == 0):
                    TemSyn.append(MedSynLargeSterm[i][j][0])
                if(j == len(np.array(MedSynLargeSterm[i]))-1):
                    TemSyn.append(MedSynLargeSterm[i][j][1])
                    TemSyn.append(count)
                    TemSyn.append(MedSynLargeSterm[i][j][3])
                    TemSyn.append(0)
                    TemSyn.append(0)
                    TemSyn.append(0)
                    TemSyn.append(0)
            SynLargeSterm.append(TemSyn)
        return SynLargeSterm
    def SecMatrixStermCreate(self, ResultStack, Matrix, PreStructureList):
        MatrixSterm = np.zeros(shape=[len(np.array(ResultStack)), len(np.array(ResultStack))])
        PairedSterm = np.zeros(shape=[len(np.array(ResultStack)), len(np.array(ResultStack))])
        Paired = []
        PairIndex = 0    # 用于记录配对茎区在Paired的存储位置
        for i in range(len(MatrixSterm)):
            if(ResultStack[i][3] == 1):
                continue
            else:
                IndexQ = ResultStack[i][1]
                IndexP = ResultStack[i][0]
                for j in range(i):
                    if (ResultStack[j][3] == 1):
                        IndexI = ResultStack[j][0]
                        IndexJ = ResultStack[j][1]
                        AllSterm, flag = self.MaxStem(IndexI, IndexJ, IndexP, IndexQ, Matrix)
                        SelectStemList = self.SelectStem(AllSterm,  flag)
                        if (len(SelectStemList) != 0):
                            OptimalStemList = self.LayerStermCom(SelectStemList, [])
                            numCount = 0
                            for num in range(len(np.array(OptimalStemList))):
                                Rate = self.RateOfSterm(ResultStack[j], ResultStack[i], OptimalStemList[num], PreStructureList)
                                if(Rate > numCount):
                                    numCount = Rate
                            MatrixSterm[i][j] = numCount  # 存储不同茎区之间的匹配使用率
                            Paired.append(OptimalStemList)  # 将匹配茎区存储与列表中
                            PairedSterm[i][j] = PairIndex  # 存放茎区在列表中存储的位置
                            PairIndex += 1
                        else:
                            MatrixSterm[i][j] = -1
        return MatrixSterm, PairedSterm, Paired
    def IntellSelectSterm(self, SynSterm, Matrix, OptimalSterm, ExtendOptimalSterm, Prestructure):
        Mat = cy.deepcopy(Matrix)
        for num in range(len(np.array(ExtendOptimalSterm))):
            for CountI in range(ExtendOptimalSterm[num][0], ExtendOptimalSterm[num][1] + 1):
                for n in range(len(np.array(Matrix))):
                    Mat[CountI][n] = 0
                    Mat[n][CountI] = 0
            for CountP in range(ExtendOptimalSterm[num][2], ExtendOptimalSterm[num][3] + 1):
                for nn in range(len(np.array(Matrix))):
                    Mat[CountP][nn] = 0
                    Mat[nn][CountP] = 0

        for Num in range(len(np.array(SynSterm))):
            if(SynSterm[Num][0] == 0):
                continue
            else:
                if(Num == 0):
                    for NumOne in range(0, SynSterm[Num][0]):
                        for nn in range(len(np.array(Matrix))):
                            Mat[NumOne][nn] = 0
                            Mat[nn][NumOne] = 0
                elif(Num == len(np.array(SynSterm))-1):
                    if(SynSterm[Num][1] < len(Prestructure)-1):
                        for NumTwo in range(SynSterm[Num-1][1]+1, SynSterm[Num][0]):
                            for nn in range(len(np.array(Matrix))):
                                Mat[NumTwo][nn] = 0
                                Mat[nn][NumTwo] = 0
                        for NumThree in range(SynSterm[Num][1]+1, len(Prestructure)):
                            for nn in range(len(np.array(Matrix))):
                                Mat[NumThree][nn] = 0
                                Mat[nn][NumThree] = 0
                    else:
                        for NumTwo in range(SynSterm[Num-1][1]+1, SynSterm[Num][0]):
                            for nn in range(len(np.array(Matrix))):
                                Mat[NumTwo][nn] = 0
                                Mat[nn][NumTwo] = 0
                else:
                    for NumFour in range(SynSterm[Num-1][1]+1, SynSterm[Num][0]):
                        for nn in range(len(np.array(Matrix))):
                            Mat[NumFour][nn] = 0
                            Mat[nn][NumFour] = 0

        AllSterm, flag = self.MaxStem(0, len(np.array(Prestructure))-1, 0, len(np.array(Prestructure))-1, Mat)
        TList = []  # 建立列表List用于存储List中满足条件的匹配茎区
        for i in range(len(np.array(AllSterm))):
            ForeNum = -1
            ErarNum = -1
            for j in range(len(np.array(SynSterm))): # 去除前面是2后面是1的茎区
                if(AllSterm[i][0] >= SynSterm[j][0] and AllSterm[i][1] <= SynSterm[j][1]):
                    ForeNum = j
                if(AllSterm[i][2] >= SynSterm[j][0] and AllSterm[i][3] <= SynSterm[j][1]):
                    ErarNum = j
            if(SynSterm[ForeNum][3] == 1 and SynSterm[ErarNum][3] == 2 ):
                TList.append(AllSterm[i])
            else:
                continue
        SelectStemList = self.SelectStem(TList, flag)
        TemList =[]
        for i in range(len(np.array(SelectStemList))):
            flag = False
            for j in range(len(np.array(OptimalSterm))):
                if(SelectStemList[i][3] < OptimalSterm[j][0] or OptimalSterm[j][3] < SelectStemList[i][0] or (SelectStemList[i][1]<OptimalSterm[j][0] and OptimalSterm[j][3]<SelectStemList[i][2]) or (OptimalSterm[j][1]<SelectStemList[i][0] and SelectStemList[i][3]<OptimalSterm[j][2])):
                    continue
                else:
                    flag = True
                    break
            if(flag == False):
                TemList.append(SelectStemList[i])
            else:
                continue
        NewOptimalSterm = []
        if(len(np.array(TemList)) == 0):
            NewOptimalSterm = [ExtendOptimalSterm]
        else:
            Combination = [OptimalSterm]
            OptimalSterm = self.LayerStermCom(TemList, Combination)
            OptimalSterm = np.array(OptimalSterm)
            for i in range(len(np.array(OptimalSterm))):
                Tem = self.IntellExtendStem(Matrix, OptimalSterm[i], Prestructure, 1, 2)
                NewOptimalSterm.append(Tem)
        return NewOptimalSterm
    def IntellExtendStem(self, Matrix, OptimalSterm, Prestructure, PreNum, ErarNum):
        Mat = cy.deepcopy(Matrix)
        for ii in range(len(np.array(OptimalSterm))):
            for nn in range(int(OptimalSterm[ii][0]), int(OptimalSterm[ii][1]+1)):
                for mm in range(len(np.array(Mat))):
                    Mat[nn][mm] = 0
                    Mat[mm][nn] = 0
            for pp in range(int(OptimalSterm[ii][2]), int(OptimalSterm[ii][3]+1)):
                for qq in range(len(np.array(Mat))):
                    Mat[qq][pp] = 0
                    Mat[pp][qq] = 0

        MedOptimal = [] # 建立中间的最优茎区， [[83, 85, 90, 92, 3], [77, 80, 94, 97,4]]， 用于存储OptimalSterm中每个茎区延长后的茎区
        for numOne in range(len(np.array(OptimalSterm))): # 遍历OptimalSterm中的每个茎区并进行处理
            Tem = []  # 创建临时列表， 用于记录每个OptimalSterm延长后的茎区
            I = int(OptimalSterm[numOne][0])  # 将当前OptimalSterm中茎区的I值赋值给I
            J = int(OptimalSterm[numOne][1])  # 将当前OptimalSterm中茎区的J值赋值给J
            P = int(OptimalSterm[numOne][2])  # 将当前OptimalSterm中茎区的P值赋值给P
            Q = int(OptimalSterm[numOne][3])  # 将当前OptimalSterm中茎区的Q值赋值给Q
            while(I > 0 and Q < len(np.array(Mat))-1): # 处理当前茎区的右上方， 当茎区的右上方没有在矩阵Mat的边界时候
                if(Mat[I-1][Q + 1] == 1):  # 若此时Mat[I-1][Q+1]即沿着右上方延长一个节点的值为1
                    I -= 1  # 此时将I的值减1，Q的值加1
                    Q += 1
                    for numTwo in range(len(np.array(Mat))): # 由于当前节点已经延申，若其他茎区也延申到该节点所在的行或列便产生冲突，所有要将延长节点的行于列记录下来
                        Mat[I][numTwo] = -1  # 将延长节点的行全部修改为 -1
                        Mat[numTwo][Q] = -1  # 将延长节点的列全部修改为 -1
                # 若当前节点所在的行或者列已经被延申，且当前节点位置Matrix[I-1][Q+1] == 1。此时两个延长茎区便产生冲突，产生出两个I对应一个Q或者两个Q对应一个I的情况
                # 此时需要比较两个起冲突的碱基对，基于先配对优先的原则，若当前配对碱基的PreStructure值为1，而起冲突的为0则修改配对信息。

                elif(Mat[I-1][Q + 1] == -1 and Matrix[I-1][Q+1] == 1):
                    Index = 0   # 定义下标用于遍历MedOptimal的茎区，由于茎区向右上方延申所以只能跟其他茎区的左下方起冲突
                    Falg = False  # 定义布尔型标签数据
                    while(Index < len(np.array(MedOptimal))):  # 当下标Index的值小于MedOptimal中的茎区个数时，进入循环
                        if(I-1 == MedOptimal[Index][1]):  # 若I-1于MedOptimal中某一茎区的J相等时，此时为一个I对应两个Q
                            # 此时比较连个碱基对的Q值所在PreStructure的值，若当前碱基对的Q+1所在的Prestructure的值大于起冲突碱基的预测值，则碱基对进行秀嘎
                            if(Prestructure[Q+1]==ErarNum and  Prestructure[MedOptimal[Index][2]] != ErarNum):
                                I -= 1  # 当前茎区进行延长
                                Q += 1
                                MedOptimal[Index][1] -= 1  # 其冲突的茎区缩减
                                MedOptimal[Index][2] += 1
                                MedOptimal[Index][4] = MedOptimal[Index][1] - MedOptimal[Index][0] + 1 # 重新定义冲突茎区的长度
                                for numThree in range(len(np.array(Mat))): # 由于碱基配对发生了修改，所以要对Mat对应的行列进行修改
                                    Mat[numThree][Q] = -1  # 把新延申的Q列值修改为-1
                                    Mat[numThree][MedOptimal[Index][2]-1] = Matrix[numThree][MedOptimal[Index][2]-1] # 恢复因茎区缩减空置的P列
                            else: # 若当前的Q值所在PreStructure的值， 不大于其冲突茎区Q所在的Prestructure的值， 证明茎区不能延申
                                Falg = True  # 将Falg赋值为True
                                break # 并退出当前循环
                        elif(Q+1 == MedOptimal[Index][2]):  # 若Q+1于起冲突茎区的P相同，此时时相同的列对应不同的行
                            if(Prestructure[I-1] == PreNum and Prestructure[MedOptimal[Index][1]] != PreNum): # 比较两个不同行碱基在PreStructure中的预测情况，若当前碱基的值大于起冲突碱基的值
                                I -= 1  # 当前遍历茎区进行延申
                                Q += 1
                                MedOptimal[Index][1] -= 1  # 起冲突的茎区进行缩减
                                MedOptimal[Index][2] += 1
                                MedOptimal[Index][4] = MedOptimal[Index][1] - MedOptimal[Index][0] + 1  # 重新定义起冲突茎区的长度
                                for numFour in range(len(np.array(Matrix))):
                                    Mat[I][numFour] = -1  # 将新产生的I行的值全部修改为-1
                                    Mat[MedOptimal[Index][1]+1][numFour] = Matrix[MedOptimal[Index][1] + 1][numFour] # 恢复因为茎区缩减空置出来的J
                            else: # 比较两个不同行碱基在PreStructure中的预测情况，若当前碱基的值不大于起冲突碱基的值
                                Falg = True   # 将Falg赋值为True
                                break         # 退出当前循环
                        else: # 当MedOptimal当前访问的茎区不满足条件时，Index加1，继续访问MedOptimal中下一个茎区
                            if(Index == len(np.array(MedOptimal)) - 1):
                                Falg = True
                                break
                            Index += 1
                    if(Falg): # 当Falg为True时候，证明当前茎区的当前方向不能继续进行延申，所以结束延申
                        break

                else:
                    break
            while(J < len(np.array(Mat))-1 and P > 0): # 茎区向左下方延申，此时可能会于其他茎区的I-Q其冲突
                if (Mat[J+1][P-1] == 1):  # 若茎区向左下方延申一个节点的Mat[J+1][P-1]为1
                    J += 1  # 茎区正常延申
                    P -= 1
                    for numFive in range(len(np.array(Mat))):  # 把延申节点所在的行列全部修改为-1
                        Mat[J][numFive] = -1
                        Mat[numFive][P] = -1
                elif(Mat[J+1][P - 1] == -1 and Matrix[J+1][P - 1] == 1):  # 若当前延申节点所在的行或者列，已被其他茎区延申占用，并且Matrix[J+1][P - 1] == 1
                    Index = 0  # 定义下标数据，对MedOptimal中的茎区进行遍历访问
                    Falg = False # 定义标签数据，指示当前茎区能否继续延申
                    while (Index < len(np.array(MedOptimal))):   #遍历访问MedOptimal中的所有茎区
                        if (J + 1 == MedOptimal[Index][0]): # 若J+1于其他茎区的I相同，及不同的列对应相同的行，此时需要比较两个列碱基的预测数据
                            if (Prestructure[P - 1] == ErarNum and  Prestructure[MedOptimal[Index][3]] != ErarNum): # 若当前的列碱基数据大于起冲突的列碱基数据
                                J += 1  # 茎区进行延申
                                P -= 1
                                MedOptimal[Index][0] += 1
                                MedOptimal[Index][3] -= 1  # 其冲突的茎区进行缩减
                                MedOptimal[Index][4] = MedOptimal[Index][1] - MedOptimal[Index][0] + 1  # 重新定义起冲突茎区的长度
                                for numSix in range(len(np.array(Mat))):
                                    Mat[numSix][P] = -1 # 将新产生的列全部修改为-1
                                    Mat[numSix][MedOptimal[Index][3] + 1] = Matrix[numSix][MedOptimal[Index][3] + 1]  # 恢复因茎区缩减空置的列，
                            else: # 若当前的列碱基数据不大于起冲突的列碱基数据
                                Falg = True  # 标签变量赋值为True
                                break  # 并退出继续遍历其他MedOptimal中的茎区
                        elif(P - 1 == MedOptimal[Index][3]):  # 若延长节点的P-1,于MedOptimal中某一茎区的Q相同，此时为一个列对应两行，此时需要比较两个行的碱基的结构预测值
                            if (Prestructure[J + 1] == PreNum and  Prestructure[MedOptimal[Index][0]] != PreNum):  # 若J+1的结构预测值大于起冲突茎区的结构预测值
                                J += 1   # 茎区进行延申，
                                P -= 1
                                MedOptimal[Index][0] += 1   # 起冲突茎区进行缩减
                                MedOptimal[Index][3] -= 1
                                MedOptimal[Index][4] = MedOptimal[Index][1] - MedOptimal[Index][0] + 1   # 重新修改起冲突茎区的长度
                                for numSeven in range(len(np.array(Mat))):
                                    Mat[J][numSeven] = -1   # 将延申节点新产生的行全部修改为-1
                                    Mat[MedOptimal[Index][0] - 1][numSeven] = Matrix[MedOptimal[Index][0] - 1][numSeven]  # 恢复因茎区缩减空置的行
                            else:  # 若当前的列碱基数据不大于起冲突的列碱基数据
                                Falg = True  # 标签数据赋值为True
                                break  # 并退出继续遍历其他MedOptimal中的茎区
                        else: # 下标加1,继续遍历访问MedOptimal中的的其他茎区
                            if(Index == len(np.array(MedOptimal)) - 1):
                                Falg = True
                                break
                            Index += 1
                    if (Falg): # 若Falg为True，停止并退出当前方向的延申
                        break

                else:
                    break
            Tem.append(I)   # 将延长后茎区的I添加到Tem列表中
            Tem.append(J)   # 将延长后茎区的J添加到Tem列表中
            Tem.append(P)   # 将延长后茎区的P添加到Tem列表中
            Tem.append(Q)  #  将延长茎区的Q添加到Tem列表中
            Tem.append(J-I + 1)  # 将延长后茎区的长度添加到Tem列表中
            MedOptimal.append(Tem)
        OptimalSterm = MedOptimal
        return OptimalSterm
    def DoubleSingleSmallSterm(self, CollecSterm,PreStructure, Matrix, CombinationOne): #  该方法用于大茎区选定优化方案后处理其附近的小茎区
        Sterm = [] # 定义Sterm列表用于收集满足条件的茎区
        MatrixSterm, PairedSterm, Paired = self.SecMatrixStermCreate(CollecSterm, Matrix, PreStructure)  # MatrixSterm存储不同茎区之间匹配使用率， PairedSterm存储收集的茎区， Paired存储茎区在PairedSterm存储收集的茎区中存储的位置
        for i in range(len(np.array(CollecSterm))): # 遍历矩阵，收集满足条件的茎区
            if(CollecSterm[i][3] == 1):   # 首先找到第一个2, 4, 6茎区
                continue
            else:
                Index = i -1
                while(Index >= 0): # 遍历当前2茎区之前的所有1茎区
                    if(CollecSterm[Index][3] == 2):
                        Index -= 1
                        continue
                    else:
                        if(MatrixSterm[i][Index] >= (1 + CollecSterm[i][2]/CollecSterm[Index][2])/2 or MatrixSterm[i][Index] >= (1 + CollecSterm[Index][2]/CollecSterm[i][2])/2 or (CollecSterm[i][2]>=4 and CollecSterm[Index][2]>=4 and MatrixSterm[i][Index]>0.8)):
                            CombinationSterm = Paired[int(PairedSterm[i][Index])] # 获得优化方案
                            for j in range(len(np.array(CombinationSterm))):
                                for num in range(len(np.array(CombinationSterm[j]))):
                                    Sterm.append(CombinationSterm[j][num])
                    Index -= 1
        if(len(np.array(Sterm)) == 0):
            Combination = CombinationOne
        else:
            Sterm = self.StermHeavyPair(Sterm)
            Sterm = np.array(Sterm)
            SelectStemListSort = Sterm[np.lexsort(-Sterm.T)]
            Combination = self.LayerStermCom(SelectStemListSort, CombinationOne)
        IntellSelect = []
        IntellSelectOptimal = []
        SynLargeSterm = self.SynSterm(CollecSterm)
        if(len(np.array(Combination)) == 0):
            MedIntellSelect = self.IntellSelectSterm(SynLargeSterm, Matrix, np.array([]), [], PreStructure)
            for j in range(len(np.array(MedIntellSelect))):
                IntellSelect.append(MedIntellSelect[j])
        else:
            for num in range(len(np.array(Combination))):
                Med = self.IntellExtendStem(Matrix, Combination[num], PreStructure, 1, 2)  #只能延长
                MedIntellSelect = self.IntellSelectSterm(SynLargeSterm, Matrix, Combination[num], Med, PreStructure)
                for j in range(len(np.array(MedIntellSelect))):
                    IntellSelect.append(MedIntellSelect[j])
        numList = []
        for i in range(len(np.array(IntellSelect))):
            num = 0
            for j in range(len(np.array(IntellSelect[i]))):
                num += IntellSelect[i][j][4]
            numList.append(num)
        if(len(np.array(numList)) != 0):
            largeNum = numList[0]
            for i in range(len(np.array(numList))):
                if (numList[i] > largeNum):
                    largeNum = numList[i]
            for i in range(len(np.array(numList))):
                if (numList[i] == largeNum):
                    IntellSelectOptimal.append(IntellSelect[i])
        return IntellSelectOptimal
    def Rate(self, CollecSterm, Combination):
        OneSterm = []
        OneLength = 0
        TwoSterm = []
        TwoLength = 0
        numOne = 0
        numTwo = 0
        for i in range(len(np.array(CollecSterm))):
            if(CollecSterm[i][3] == 1 or CollecSterm[i][3] == 3 or CollecSterm[i][3] == 5):
                OneSterm.append(CollecSterm[i])
                OneLength += CollecSterm[i][2]
            else:
                TwoSterm.append(CollecSterm[i])
                TwoLength += CollecSterm[i][2]
        for i in range(len(np.array(Combination))):
            for p in range(Combination[i][0], Combination[i][1] + 1):
                flagOne = False
                for q in range(len(np.array(OneSterm))):
                    if(p<OneSterm[q][0] or p>OneSterm[q][1]):
                        continue
                    else:
                        flagOne = True
                        break
                if(flagOne):
                    numOne += 1
            for pp in range(Combination[i][2], Combination[i][3] + 1):
                flagTwo = False
                for qq in range(len(np.array(TwoSterm))):
                    if (pp < TwoSterm[qq][0] or pp > TwoSterm[qq][1]):
                        continue
                    else:
                        flagTwo = True
                        break
                if(flagTwo):
                    numTwo += 1
        rateOne = numOne/OneLength
        rateTwo = numTwo/TwoLength
        return rateOne, rateTwo
    def CreateSynMatrix(self, ResultStack, Matrix, PreStructure):
        Med = []   # 用来存储每个每个合成大茎区中长度最大的独立茎区
        Index = 0
        while(Index < len(np.array(ResultStack))):
            CollectionSterm = self.SynCollection(Index, ResultStack)  # 将间隔小于三个碱基的茎区是为一个茎区区域
            pos = -1
            num = -1
            for i in range(len(np.array(CollectionSterm))): # 确定该茎区区域的最大茎区位置和长度
                if(CollectionSterm[i][2] > num):
                    num = CollectionSterm[i][2]
                    pos = i
            Med.append(CollectionSterm[pos]) # Med用来存储最大茎区
            Index = CollectionSterm[-1][7] + 1
        SynStermMatrixNone = np.zeros(shape=[len(np.array(Med)), len(np.array(Med))])
        countMatrix = np.zeros(shape=[len(np.array(Med)), len(np.array(Med))])
        CombinationList = []
        count = -1

        for i in range(len(np.array(Med))):
            if (Med[i][3] == 1):
                continue
            else:
                PositionTwo = Med[i][7]
                for j in range(i):
                    if (Med[j][3] == 1):
                        PositionOne = Med[j][7]   # 确定最大茎区在茎区序列里的位置
                        CollecSterm = self.CollectionDoubleSterm(PositionOne, PositionTwo, ResultStack)  # 收集PoaitionOne、PositionTwo附近小茎区及其内部未出栈茎区
                        CombinationNone = self.DoubleSingleSmallSterm(CollecSterm,PreStructure, Matrix, [])
                        count += 1
                        CombinationList.append(CombinationNone)
                        countMatrix[i][j] = count
                        CorrectRate = -1
                        CollecSterm = self.CollectionDoubleSterm(PositionOne, PositionTwo, ResultStack)
                        if (len(np.array(CombinationNone)) == 1):
                            rateOne, rateTwo = self.Rate(CollecSterm, CombinationNone[0])
                            SynStermMatrixNone[i][j] = (rateOne + rateTwo) / 2
                        elif (len(np.array(CombinationNone)) == 0):
                            SynStermMatrixNone[i][j] = -1
                        else:
                            for num in range(len(np.array(CombinationNone))):
                                rateOne, rateTwo = self.Rate(CollecSterm, CombinationNone[num])
                                if ((rateOne + rateTwo) / 2 > CorrectRate):
                                    CorrectRate = (rateOne + rateTwo) / 2
                            SynStermMatrixNone[i][j] = CorrectRate
        return SynStermMatrixNone, Med, countMatrix, CombinationList
    def CombinationStermCollection(self, Combination): # 把收集到的优化茎区拆分出来,并且已经去重
        SplitList = []
        for i in range(len(np.array(Combination))):
            for j in range(len(np.array(Combination[i]))):
                SplitList.append(Combination[i][j])
        return SplitList
    def FinalResult(self, SynStermMatrixNone, Med, SynSterm, countMatrix, CombinationList, Combination):
        CorrectSterm = []
        for i in range(len(np.array(SynStermMatrixNone))):
            if (Med[i][3] == 1 or  Med[i][5] == 1):
                continue
            else:
                j = i - 1
                while (j >= 0):
                    flag = False
                    if (SynStermMatrixNone[i][j] >= 0.9 and Med[j][5] == 0 and Med[i][2] >= 4 and Med[j][2] >= 4):
                        Med[i][5] = 1
                        Med[j][5] = 1
                        flag = True
                        Split = self.CombinationStermCollection(CombinationList[int(countMatrix[i][j])])
                        for num in range(len(np.array(Split))):
                            CorrectSterm.append(Split[num])
                    if (flag):
                        break
                    j -= 1
        for i in range(len(np.array(SynStermMatrixNone))):
            if (Med[i][3] == 1 or Med[i][5] == 1):
                continue
            else:
                j = i - 1
                while (j >= 0):
                    if((Med[j][3] == 2 or Med[j][3] == 4 or Med[j][3] == 6) and Med[j][2] > 1 and Med[j][5] == 0):
                        break
                    if((Med[j][3] == 1 or Med[j][3] == 3 or Med[j][3] == 5) and Med[j][2] > 1 and SynStermMatrixNone[i][j]<0.81 and Med[j][5] == 0):
                        break
                    if ((SynStermMatrixNone[i][j] >= 0.81 and Med[j][5] == 0) or(SynStermMatrixNone[i][j] >= 0.75 and Med[j][5] == 0 and CombinationList[int(countMatrix[i][j])][0][0][4] >=5)):
                        Med[i][5] = 1
                        Med[j][5] = 1
                        Split = self.CombinationStermCollection(CombinationList[int(countMatrix[i][j])])
                        for num in range(len(np.array(Split))):
                            CorrectSterm.append(Split[num])
                        break
                    j -= 1
        if (len(np.array(CorrectSterm)) == 0):
            Combination = Combination
        else:
            CorrectSterm = self.StermHeavyPair(CorrectSterm)
            CorrectSterm = np.array(CorrectSterm)
            SelectStemListSort = CorrectSterm[np.lexsort(-CorrectSterm.T)]
            Combination = self.LayerStermCom(SelectStemListSort, Combination)
        RemainMed = []
        for i in range(len(np.array(Med))):
            if (Med[i][5] == 0):
                RemainMed.append(Med[i])
        return Combination, RemainMed
    def Collection(self, PositionOne, PositionTwo, ResultStack):
        CollectionSterm = []
        Index = PositionOne
        while(Index > 0):
            if(ResultStack[Index][4]<= 3 and ResultStack[Index][4] != -1 and ResultStack[Index-1][5] == 0):
                CollectionSterm.append(ResultStack[Index-1])
            else:
                break
            Index -= 1
        CollectionSterm.reverse()
        for i in range(PositionOne, PositionTwo+1):
            CollectionSterm.append(ResultStack[i])
        for i in range(PositionTwo+1, len(ResultStack)):
            if(ResultStack[i][4]<= 3 and ResultStack[i][4] != -1 and ResultStack[i][5] == 0):
                CollectionSterm.append(ResultStack[i])
            else:
                break
        return CollectionSterm
    def OptiFinalResult(self, RemainMed, ResultStack, Combination, PreStructure, Matrix):

        CollectionSingle = []
        for i in range(len(np.array(RemainMed))):
            CollectionSterm = self.SynCollection(RemainMed[i][7], ResultStack)
            for j in range(len(np.array(CollectionSterm))):
                CollectionSingle.append(CollectionSterm[j])
        if (len(np.array(CollectionSingle)) <= 1):
            Combination = Combination
        else:
            CollecSterm = self.Collection(0, len(np.array(CollectionSingle)) - 1,CollectionSingle)  # 收集PoaitionOne、PositionTwo附近小茎区及其内部未出栈茎区
            Combination = self.DoubleSingleSmallSterm(CollecSterm, PreStructure, Matrix, Combination)
        return Combination
    def ThirdExtendMatrixStermCreate(self, ResultStack, Matrix, PreStructureList):
        MatrixSterm = np.zeros(shape=[len(np.array(ResultStack)), len(np.array(ResultStack))])
        PairedSterm = np.zeros(shape=[len(np.array(ResultStack)), len(np.array(ResultStack))])
        MedOptimal = []   # 用于记录配对茎区在Paired的存储位置
        for i in range(len(MatrixSterm)):
            if(ResultStack[i][3] == 1):
                continue
            else:
                IndexQ = ResultStack[i][1]
                IndexP = ResultStack[i][0]
                for j in range(i):
                    if (ResultStack[j][3] == 1):
                        IndexI = ResultStack[j][0]
                        IndexJ = ResultStack[j][1]  # +1
                        AllSterm, flag = self.MaxStem(IndexI, IndexJ, IndexP, IndexQ, Matrix)
                        SelectStemList = self.SelectStem(AllSterm,  flag)
                        if (len(SelectStemList) != 0):
                            OptimalStemList = self.LayerStermCom(SelectStemList, [])
                            numCount = 0
                            StermLength = 0
                            MedExtend = []
                            for num in range(len(np.array(OptimalStemList))):
                                ExtendOptimal = self.IntellExtendStem(Matrix, OptimalStemList[num], PreStructureList, 1, 2)
                                MedExtend.append(ExtendOptimal[0])
                                Rate = self.RateOfSterm(ResultStack[j], ResultStack[i], ExtendOptimal, PreStructureList)
                                if(Rate > numCount):
                                    numCount = Rate
                                    StermLength = ExtendOptimal[0][4]
                            if(StermLength >= 3):
                                MedOptimal.append(MedExtend)
        return MedOptimal
    def MainFuntion(self, FirstLayerStack, SecondaryLayerStack, ThirdLarerStack, PreStructureList, PriList):
        Matrix = self.MatrixCreate(PriList, PreStructureList)
        FirstFinal = []
        SecondaryFinal = []
        ThirdFinal = []
        Combination = []
        CombinaFinal = []
        if(len(np.array(FirstLayerStack)) != 0):
            for nnn in range(len(np.array(FirstLayerStack))):
                FirstLayerStack[nnn][7] = nnn
            TwoSuccess = self.MatrixStermCreate(FirstLayerStack, Matrix, PreStructureList)
            CombinationFirst = self.CorrectSterm(TwoSuccess, Matrix, PreStructureList)
            if (len(np.array(FirstLayerStack)) != 0):
                SecSucc = self.SecondaryMatrixStermCreate(FirstLayerStack, Matrix, PreStructureList)
            else:
                SecSucc = []
            if (len(np.array(SecSucc)) != 0):
                CombinationSecondary = self.LayerStermCom(SecSucc,CombinationFirst)  # = BasisFunction.SecondaryCorrectSterm(SecSucc, Matrix, PreStructureList, CombinationFirst)
            else:
                CombinationSecondary = CombinationFirst

            ThirdSucc = self.ThirdMatrixStermCreate(FirstLayerStack, Matrix, PreStructureList)
            CombinationThird = self.LayerStermCom(ThirdSucc, CombinationSecondary)
            for ii in range(len(np.array(CombinationThird))):
                FirstFinal.append(CombinationThird[ii])
        if(len(np.array(SecondaryLayerStack)) != 0):
            for nnn in range(len(np.array(SecondaryLayerStack))):
                SecondaryLayerStack[nnn][7] = nnn
                if(SecondaryLayerStack[nnn][3] == 3):
                    SecondaryLayerStack[nnn][3] = 1
                if(SecondaryLayerStack[nnn][3] == 4):
                    SecondaryLayerStack[nnn][3] = 2
            TwoSuccess2 = self.MatrixStermCreate(SecondaryLayerStack, Matrix, PreStructureList)
            CombinationFirst2 = self.CorrectSterm(TwoSuccess2, Matrix, PreStructureList)
            if (len(np.array(SecondaryLayerStack)) != 0):
                SecSucc2 = self.SecondaryMatrixStermCreate(SecondaryLayerStack, Matrix, PreStructureList)
            else:
                SecSucc2 = []
            if (len(np.array(SecSucc)) != 0):
                CombinationSecondary2 = self.LayerStermCom(SecSucc2,CombinationFirst2)  # = BasisFunction.SecondaryCorrectSterm(SecSucc, Matrix, PreStructureList, CombinationFirst)
            else:
                CombinationSecondary2 = CombinationFirst2
            ThirdSucc2 = self.ThirdMatrixStermCreate(SecondaryLayerStack, Matrix, PreStructureList)
            CombinationThird2 = self.LayerStermCom(ThirdSucc2, CombinationSecondary2)
            for ii in range(len(np.array(CombinationThird2))):
                SecondaryFinal.append(CombinationThird2[ii])
        if (len(np.array(ThirdLarerStack)) != 0):
            for nnn in range(len(np.array(ThirdLarerStack))):
                ThirdLarerStack[nnn][7] = nnn
                if(ThirdLarerStack[nnn][3] == 5):
                    ThirdLarerStack[nnn][3] = 1
                if(ThirdLarerStack[nnn][3] == 6):
                    ThirdLarerStack[nnn][3] = 2
            TwoSuccess3 = self.MatrixStermCreate(ThirdLarerStack, Matrix, PreStructureList)
            CombinationFirst3 = self.CorrectSterm(TwoSuccess3, Matrix, PreStructureList)
            if (len(np.array(ThirdLarerStack)) != 0):
                SecSucc3 = self.SecondaryMatrixStermCreate(ThirdLarerStack, Matrix, PreStructureList)
            else:
                SecSucc3 = []
            if (len(np.array(SecSucc)) != 0):
                CombinationSecondary3 = self.LayerStermCom(SecSucc3,CombinationFirst3)  # = BasisFunction.SecondaryCorrectSterm(SecSucc, Matrix, PreStructureList, CombinationFirst)
            else:
                CombinationSecondary3 = CombinationFirst3
            ThirdSucc3 = BasisFunction.ThirdMatrixStermCreate(ThirdLarerStack, Matrix, PreStructureList)
            CombinationThird3 = BasisFunction.LayerStermCom(ThirdSucc3, CombinationSecondary3)
            for ii in range(len(np.array(CombinationThird3))):
                ThirdFinal.append(CombinationThird3[ii])
        MedCom = []
        if(len(np.array(SecondaryFinal)) != 0):
            for i in range(len(np.array(FirstFinal))):
                for j in range(len(np.array(SecondaryFinal))):
                    TemCombintion = FirstFinal[i]
                    for m in range(len(np.array(SecondaryFinal[j]))):
                        TemCombintion.append(SecondaryFinal[j][m])
                    MedCom.append(TemCombintion)
            Combination = cy.deepcopy(MedCom)
        else:
            Combination = cy.deepcopy(FirstFinal)
        if (len(np.array(ThirdFinal)) != 0):
            for i in range(len(np.array(Combination))):
                for j in range(len(np.array(ThirdFinal))):
                    TemCombintion = Combination[i]
                    for m in range(len(np.array(ThirdFinal[j]))):
                        TemCombintion.append(ThirdFinal[j][m])
                    MedCom.append(TemCombintion)
            Combination = cy.deepcopy(MedCom)
        else:
            Combination = Combination
        for ii in range(len(np.array(Combination))):
            Tem = self.IntellExtendStem(Matrix, np.array(Combination[ii]), PreStructureList, 1, 2)
            CombinaFinal.append(Tem)
        return CombinaFinal