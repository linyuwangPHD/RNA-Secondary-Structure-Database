import h5py as h5
import numpy as np
class DataRead:
    def PriArchiveData(self): # 读取数据， 将已存储好的数据读取出来
        PriTestFile = h5.File('Validation/Tenth/5sRNAData-7.h5', 'r')  # 建立读取测试文件数据
        PriTestSeqList = PriTestFile['SeqList'][:]  # 读取测试的序列数据
        PriTestStructureList = PriTestFile['StructureList'][:]  # 读取测试的结构数据
        PriTestLengthList = PriTestFile['Length'][:]  # 读取测试的长度数据
        PriTestList = PriTestFile['PriList'][:]  # 读取测试数据的完整序列及结构信息
        PriFileTestIndex = PriTestFile['FileIndex'][:]
        # 将读取的数据返回
        return PriTestSeqList, PriTestStructureList, PriTestLengthList, PriTestList, PriFileTestIndex  # 数据类型均为<class 'numpy.ndarray'>
    def PreStructureData(self):
        PreSecStructureTest = h5.File('Validation/Tenth/OLD5sRNA-7.h5', 'r') # 建立读取测试数据的预测结构信息文件
        PreStructureTest = PreSecStructureTest['PreStructure'][:]  # 读取测试数据的预测结构信息
        PreSecStructureTest.close()
        # 将读取的数据返回
        return PreStructureTest   # 数据类型均为<class 'numpy.ndarray'>