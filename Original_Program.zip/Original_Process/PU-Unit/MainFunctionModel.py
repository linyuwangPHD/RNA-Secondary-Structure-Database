import numpy as np
import DataReadClass as dr
import BasisFuncTionClass as bf
import tensorflow as tf
DataRead = dr.DataRead()
PriTestSeqList, PriTestStructureList, PriTestLengthList, PriTestList, PriFileTestIndex = DataRead.PriArchiveData() # 数据类型均为<class 'numpy.ndarray'>
PreStructureTest = DataRead.PreStructureData()
BasisFunction = bf.BasisFunction()
Index = 0
Count = 0
AllPPV = 0
AllSen = 0
AllFscore = 0
Corr = 0
Num = 0
'''for i in range(len(np.array(PriFileTestIndex))):
    print(PriFileTestIndex[i])
    print(PriTestLengthList[i])'''
while(Index < len(np.array(PriTestList))):
    #break
    PriStructure = []
    AllPreStructure = []
    AllPriList = []
    if(Index != len(np.array(PriTestList))-1):
       if(PriFileTestIndex[Index] != PriFileTestIndex[Index + 1]):
           for i in range(PriTestLengthList[Index]):
               PriStructure.append(PriTestStructureList[Index][i])
               AllPreStructure.append(PreStructureTest[Index][i])
               AllPriList.append(PriTestList[Index][i])
           Index += 1
       else:
           for i in range(200):
               PriStructure.append(PriTestStructureList[Index][i])
               AllPreStructure.append(PreStructureTest[Index][i])
               AllPriList.append(PriTestList[Index][i])
           Index += 1
           while(Index < len(np.array(PriTestList)) and PriFileTestIndex[Index] == PriFileTestIndex[Index-1]):
               if(Index != len(np.array(PriTestList))-1):
                   if(PriFileTestIndex[Index] == PriFileTestIndex[Index+1]):
                       for i in range(100,200):
                           PriStructure.append(PriTestStructureList[Index][i])
                           AllPreStructure.append(PreStructureTest[Index][i])
                           AllPriList.append(PriTestList[Index][i])
                   else:
                       for i in range(100, PriTestLengthList[Index]):
                           PriStructure.append(PriTestStructureList[Index][i])
                           AllPreStructure.append(PreStructureTest[Index][i])
                           AllPriList.append(PriTestList[Index][i])
               else:
                    for i in range(100, PriTestLengthList[Index]):
                        PriStructure.append(PriTestStructureList[Index][i])
                        AllPreStructure.append(PreStructureTest[Index][i])
                        AllPriList.append(PriTestList[Index][i])
               Index += 1
    else:
        for i in range(PriTestLengthList[Index]):
            PriStructure.append(PriTestStructureList[Index][i])
            AllPreStructure.append(PreStructureTest[Index][i])
            AllPriList.append(PriTestList[Index][i])
        Index += 1
    '''print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    print(len(AllPreStructure))
    print(len(PriStructure))'''
    Pri = np.argmax(PriStructure, 1)
    Pre = np.argmax(AllPreStructure, 1)
    for iii in range(len(np.array(Pri))):
        if(Pri[iii] == Pre[iii]):
            Corr += 1
        Num += 1

    PreStructureList = BasisFunction.ConvergeToPri(np.array(AllPreStructure))  # 类型为<class 'list'>
    '''for i in range(len(np.array(PreStructureList))):
        print("@@@@@@@@@@@@@@@@@")
        print(i)
        print(PreStructureList[i])
        print(Pre[i])
        print(Pri[i])'''
    ResultStack,FirstLayerStack, SecondaryLayerStack, ThirdLarerStack= BasisFunction.CreateStructureStack(PreStructureList)
    #print(np.array(ResultStack))
    #print(np.array(FirstLayerStack))
    #print(np.array(SecondaryLayerStack))
    #print(np.array(ThirdLarerStack))
    Combination = BasisFunction.MainFuntion(FirstLayerStack, SecondaryLayerStack, ThirdLarerStack, PreStructureList, AllPriList)
    #for ii in range(len(np.array(CombinationThird))):
    #    Tem = BasisFunction.IntellExtendStem(Matrix, np.array(CombinationThird[ii]), PreStructureList, 1, 2)
    #    CombinationFinal.append(Tem)
    Ppv = 0
    Sen = 0
    Fscore = 0
    print("@@@@@@@@@@@@@@@@@@########asdddddddddddddddddddd###########################")
    #print(np.array(CombinationFinal))
    for i in range(len(np.array(Combination))):
        PPV, Sensitive, Fs = BasisFunction.ValueOfPPVSen(AllPriList, Combination[i])
        print("###########")
        print(PPV)
        print(Sensitive)
        print(Fs)
        if (Fs > Fscore):
            Sen = Sensitive
            Ppv = PPV
            Fscore = Fs
    AllPPV += Ppv
    AllSen += Sen
    AllFscore += Fs
    Count += 1
    print("$$$$$$$$$$$$$$$$$$$$$$$$$")
    #print(np.array(CombinationFinal))
    print(Index)
    print(Ppv)
    print(Sen)
    print(AllPPV / Count)
    print(AllSen / Count)
    print(AllFscore/Count)
print(Corr)
print(Num)
print(Corr/Num)